/* TechRental · front-end ligado ao banco de dados MySQL (via login.php e api.php).
   - Os dados vêm de api.php?a=estado e são conferidos a cada poucos segundos (tempo real entre telas, abas e usuários).
   - Toda ação (aprovar, devolver, cadastrar...) vai para o banco e a tela é redesenhada com o que o banco devolveu.
   - Quem está logado e o perfil vivem na sessão PHP; o navegador não guarda nem decide nada disso. */

/* ---------- tabelas de apoio (rótulos e cores) ---------- */
// Setores: o login usa estes valores padrão; depois do login eles são substituídos pelos do banco.
let SET = { dev: ['Desenvolvimento de Software', 'Software'], pd: ['Engenharia e Prototipagem (P&amp;D)', 'P&amp;D'], cp: ['Implantação e Operações em Campo', 'Campo'], ms: ['Manutenção e Suporte Técnico', 'Suporte'] };
const MAIL = { dev: 'gestor.software', pd: 'gestor.pd', cp: 'gestor.campo', ms: 'gestor.suporte' };
const PERF = { a: 'Almoxarifado e Patrimônio', d: 'Diretoria' };
const ST = { d: ['verde', 'Disponível'], e: ['amarelo', 'Emprestado'], a: ['vermelho', 'Atrasado'], m: ['amarelo', 'Em manutenção'], i: ['cinza', 'Descartado'] };
const DS = { open: ['vermelho', 'Em aberto'], ok: ['verde', 'Íntegro'], rep: ['verde', 'Reposição simples'], man: ['amarelo', 'Manutenção'], des: ['cinza', 'Descartado'] };
const DEST = { ABERTO: 'open', INTEGRO: 'ok', REPOSICAO_SIMPLES: 'rep', MANUTENCAO: 'man', DESCARTADO: 'des' };
const STL = { DISPONIVEL: 'd', EMPRESTADO: 'e', ATRASADO: 'a', MANUTENCAO: 'm', DESCARTADO: 'i' };
const CK = ['Equipamento principal', 'Carregador / fonte', 'Cabos fornecidos', 'Acessórios da retirada', 'Sem avarias físicas visíveis']; // ids 1..5 em checklist_itens
const MENU = {
  a: [['Painel', 'painel'], ['Catálogo', 'catalogo'], ['Solicitações', 'solicitacoes'], ['Empréstimos', 'emprestimos'], ['Histórico', 'historico'], ['Manutenção', 'manutencao'], ['Cadastros', 'cadastros']],
  g: [['Painel', 'painel'], ['Catálogo', 'catalogo'], ['Nova retirada', 'nova-retirada'], ['Meus empréstimos', 'emprestimos'], ['Extensões', 'extensoes'], ['Histórico', 'historico']],
  d: [['Painel', 'painel'], ['Aprovações', 'aprovacoes'], ['Catálogo', 'catalogo'], ['Histórico', 'historico'], ['Setores', 'setores']]
};
const LOGO = '<svg viewBox="0 0 34 34" aria-hidden="true"><rect width="34" height="34" rx="6" fill="#ac1a3f"/><path d="M9 7h11l5 5v15H9z" fill="#fff"/><path d="M13 17h8m0 0-2.5-2.5M21 17l-2.5 2.5M21 22h-8m0 0 2.5-2.5M13 22l2.5 2.5" stroke="#ac1a3f" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';

/* ---------- dados (preenchidos a partir do banco) ---------- */
let CAT = [], CATR = [], IT = [], EMP = {}, SOL = [], EXT = [], COMPRA = [], MAN = [], HISR = [], USERS = [], SETR = [];
let U = null, CSRF = '', HASH = '';

const E = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); // tudo que vem do banco é escapado
const dm = s => s ? s.slice(8, 10) + '/' + s.slice(5, 7) : '—';
const dmh = s => s ? dm(s) + ' ' + s.slice(11, 16) : '—';
const dmyh = s => s ? dm(s) + '/' + s.slice(0, 4) + ' ' + s.slice(11, 16) : '—';
const dia = s => s ? s.slice(0, 10) : '';

function aplicar(j) {
  U = { p: j.eu.p, s: j.eu.s, nome: j.eu.nome, id: j.eu.id };
  CSRF = j.csrf; HASH = j.h;
  SETR = j.setores; SET = {};
  j.setores.forEach(s => { SET[s.sigla] = [E(s.nome), E(s.nome_curto), s.id, +s.ativo]; });
  CATR = j.cats; CAT = j.cats.map(c => E(c.nome));
  IT = j.eq.map(q => ({ id: +q.id, c: E(q.codigo_patrimonio), n: E(q.nome), nr: q.nome, k: j.cats.findIndex(c => c.id == q.categoria_id), cid: +q.categoria_id, s: q.setor_sigla, sid: +q.setor_id, st: STL[q.status], uso: E(q.uso_principal || '—'), usoRaw: q.uso_principal || '', cond: q.condicao_inicial }));
  EMP = {};
  j.emp.forEach(e => { EMP[E(e.codigo_patrimonio)] = [E(e.codigo_os), dm(e.prazo_devolucao), { NAO_UTILIZADA: 'n', PENDENTE: 'p', UTILIZADA: 'u' }[e.extensao_status], E(e.situacao_prazo), +e.emprestimo_id, e.prazo_devolucao, e.retirado_em]; });
  SOL = j.sol.map(s => ({ id: +s.emprestimo_id, it: E(s.codigo_patrimonio), os: E(s.codigo_os), pz: dm(s.prazo_previsto || s.prazo_devolucao), pzv: dia(s.prazo_previsto || s.prazo_devolucao), by: E(s.solicitante), st: 'p' }));
  EXT = j.ext.map(x => ({ id: +x.extensao_id, emp: +x.emprestimo_id, it: E(x.codigo_patrimonio), os: E(x.codigo_os), n: E(x.equipamento), setor: E(x.setor), de: dm(x.prazo_atual), para: dm(x.novo_prazo), parav: dia(x.novo_prazo), j: E(x.justificativa), jraw: x.justificativa, st: { PENDENTE: 'p', APROVADA: 'ok', RECUSADA: 'no' }[x.status] }));
  COMPRA = j.compra.map(x => ({ id: +x.alerta_id, it: E(x.codigo_patrimonio), n: E(x.equipamento), setor: E(x.setor), motivo: E(x.motivo), st: x.status == 'PENDENTE' ? 'p' : 'a' }));
  MAN = j.man.map(m => ({ id: +m.manutencao_id, c: E(m.codigo_patrimonio), n: E(m.equipamento), setor: E(m.setor), motivo: E(m.motivo), data: dm(m.enviado_em), et: m.etapa == 'EM_REPARO' ? 'of' : 'c' }));
  HISR = j.his; USERS = j.usuarios;
}

/* ---------- comunicação com o servidor ---------- */
async function api(a, d = {}) {
  let r, j;
  try { r = await fetch('api.php?a=' + a, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF': CSRF }, body: JSON.stringify(d) }); j = await r.json(); }
  catch (e) { throw new Error('Sem conexão com o servidor. Tente de novo.'); }
  if (r.status == 401 && j.login) { location = 'login.php'; throw new Error(j.erro); }
  if (!j.ok) throw new Error(j.erro || 'Erro inesperado.');
  return j;
}
// Executa uma ação no banco, atualiza os dados e redesenha a tela com a mensagem de sucesso (ou o erro).
async function exec(a, d, depois) {
  X.err = ''; X.m = '';
  try { const j = await api(a, d); X.m = j.msg || ''; if (depois) depois(j); await carregar(true); return j; }
  catch (e) { X.err = e.message; draw(); return null; }
}

/* ---------- utilidades ---------- */
const P = document.body.dataset.p, Q = new URLSearchParams(location.search), $ = s => document.querySelector(s);
const X = { v: {}, f: 'todos', t: 'x', m: '', err: '', ed: null, dirty: false, pend: false }; // estado da tela
const F = p => ({ detalhe: 'detalhe-equipamento', devolucao: 'registrar-devolucao' }[p] || p) + '.php';
const ACT = { detalhe: 'catalogo', devolucao: 'emprestimos' };
const item = c => IT.find(x => x.c === E(c));
const sel = (c, t) => `<span class="selo selo-${c}">${t}</span>`;
const cod = c => `<span class="codigo">${c}</span>`;
const cor = s => s.startsWith('Atras') ? 'vermelho' : s.startsWith('Devolve') ? 'amarelo' : 'verde';
const cab = (r, t) => `<div class="cabecalho-pagina"><p class="rotulo-mono">${r}</p><h1>${t}</h1></div>`;
const ind = (l, n, t, al) => `<div class="indicador${al ? ' alerta' : ''}"><p class="rotulo-mono">${l}</p><div class="numero">${n}</div><p>${t}</p></div>`;
const tab = (th, rows) => `<div class="cartao"><table class="tabela"><thead><tr>${th.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(x => `<td>${x}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${th.length}">Nada por aqui.</td></tr>`}</tbody></table></div>`;
const btn = (t, a, i, c = 'btn-neutro') => `<button type="button" class="${c}" data-a="${a}" data-i="${i}">${t}</button>`;
const pills = (lista, atual, a) => `<div class="filtros">${lista.map(([k, t]) => `<button type="button" class="filtro${k == atual ? ' ativo' : ''}" data-a="${a}" data-i="${k}">${t}</button>`).join('')}</div>`;
const v = n => E(X.v[n] ?? '');
const msg = () => (X.m ? `<div class="caixa-info msg">${E(X.m)}</div>` : '') + (X.err ? `<div class="erro">${E(X.err)}</div>` : '');
const campo = (l, inner) => `<div class="campo-form"><label>${l}</label>${inner}</div>`;
const opts = (lista, atual) => lista.map(([k, t]) => `<option value="${k}"${String(k) === String(atual) ? ' selected' : ''}>${t}</option>`).join('');
const setAtivos = () => Object.keys(SET).filter(k => SET[k][3]);
const atencao = l => `<aside class="cartao"><div class="cartao-titulo rotulo-mono">Atenção agora</div><div class="lista-atencao">${l.map(([h, t]) => `<div class="item-atencao"><h3>${h}</h3><p>${t}</p></div>`).join('')}</div></aside>`;
const vis = () => U.p == 'g' ? IT.filter(x => x.s == U.s) : IT;
const nSet = k => IT.filter(x => x.s == k);
const uso = () => tab(['Setor', 'Emprestados', 'Atrasados', 'Em manutenção'], setAtivos().map(k => [SET[k][1], nSet(k).filter(x => EMP[x.c]).length, nSet(k).filter(x => x.st == 'a').length, nSet(k).filter(x => x.st == 'm').length]));
const nomeSetor = k => SET[k] ? SET[k][1] : '—';

// histórico de um equipamento (vem do banco)
function hist(x) {
  return HISR.filter(h => h.equipamento_id == x.id).map(h => [dmh(h.retirado_em), E(h.codigo_os), h.devolvido_em ? dmh(h.devolvido_em) : '—', DEST[h.destino_vistoria], h.destino_vistoria == 'ABERTO' ? 'Em uso pelo setor.' : E(h.observacao || '—')]);
}

/* ---------- barra de navegação (muda por perfil) ---------- */
function nav() {
  const m = MENU[U.p].slice();
  if (U.p == 'g' && U.s == 'ms') m.splice(4, 0, ['Oficina', 'manutencao']); // só o Gestor de Suporte
  const nome = U.p == 'g' ? nomeSetor(U.s) : PERF[U.p];
  return `<header class="navbar"><a href="painel.php" class="logo" style="text-decoration:none">${LOGO}<span>Tech<strong>Rental</strong></span></a>
  <ul class="menu">${m.map(x => `<li><a href="${F(x[1])}" class="${(ACT[P] || P) == x[1] ? 'ativo' : ''}">${x[0]}</a></li>`).join('')}</ul>
  <div class="navbar-direita"><span class="ao-vivo" id="aovivo" title="Os dados se atualizam sozinhos a partir do banco"><i></i>ao vivo</span>
  <div class="usuario"><div class="usuario-info"><span class="usuario-perfil">SETOR LOGADO</span><span class="usuario-nome">${nome}</span></div><a href="login.php" class="btn-neutro" id="sair">Sair</a></div></div></header>`;
}

/* ---------- telas ---------- */
const R = {};

R.login = () => {
  const p = X.v.perfil || 'g', st = X.v.setor || 'dev', em = (p == 'g' ? MAIL[st] : { a: 'almoxarifado', d: 'diretoria' }[p]) + '@techrental.com';
  return `<div class="logo"><img class="logo-login" src="img/logo-techrental.png" alt="TechRental"></div>
  <main class="cartao-login ${Q.get('erro') ? 'com-erro' : ''}" id="cartao-login"><p class="rotulo-mono">Acesso restrito · uso interno</p><h1>Entrar no sistema</h1>
  <p class="mensagem-erro" role="alert">E-mail ou senha incorretos. Confira os dados e tente novamente.</p>
  <form id="f-login"><div class="campo"><label>Perfil de acesso</label>${pills([['a', 'Almoxarifado'], ['g', 'Gestor'], ['d', 'Diretoria']], p, 'perfil')}</div>
  ${p == 'g' ? `<div class="campo"><label for="setor">Setor</label><div class="campo-input"><select id="setor" name="setor" class="input-texto">${Object.keys(SET).map(k => `<option value="${k}"${k == st ? ' selected' : ''}>${SET[k][0]}</option>`).join('')}</select></div></div>` : ''}
  <div class="campo"><label for="email">E-mail</label><div class="campo-input"><input type="email" id="email" value="${em}" required></div></div>
  <div class="campo"><label for="senha">Senha</label><div class="campo-input"><input type="password" id="senha" value="12345678" required></div></div>
  <button type="submit" class="btn-entrar">Entrar</button></form>
  <p class="aviso-acesso">Acesso exclusivo para usuários cadastrados. Para obter ou recuperar o acesso, fale com o Almoxarifado.</p></main>
  <p class="rotulo-mono rodape-login">TechRental · sistema interno de empréstimos</p>`;
};

R.painel = () => {
  const V = vis(), ab = V.filter(x => EMP[x.c]), at = V.filter(x => x.st == 'a'), sol = SOL.filter(x => x.st == 'p'), ex = EXT.filter(x => x.st == 'p'), cp = COMPRA.filter(x => x.st == 'p');
  if (U.p == 'g') {
    return cab('Setor · ' + nomeSetor(U.s), 'Painel do setor') + msg() + `<section class="indicadores">${ind('Itens do setor', V.length, 'vinculados ao setor')}${ind('Emprestados', ab.length, 'com OS ativa')}${ind('Em atraso', at.length, 'sem bloqueio de novos pedidos', 1)}${ind('Extensões pendentes', ex.length, 'aguardando a Diretoria')}</section>
    <div class="painel-grade">${tab(['Item', 'OS', 'Prazo', ''], ab.map(x => [cod(x.c) + '<br>' + x.n, EMP[x.c][0], sel(cor(EMP[x.c][3]), EMP[x.c][3]), EMP[x.c][2] == 'n' ? '<a class="btn-neutro" href="extensoes.php">Pedir extensão</a>' : sel('cinza', EMP[x.c][2] == 'p' ? 'Extensão pendente' : 'Extensão usada')]))}
    ${atencao([['Devolução em mãos', 'Leve o item ao Almoxarifado, que faz a vistoria e registra a devolução.'], ['Solicitações aguardando', sol.length + ' pedido(s) de retirada aguardando o Almoxarifado.'], ['Atraso não bloqueia o setor', 'Você pode seguir fazendo novas retiradas.']])}</div>`;
  }
  if (U.p == 'a') {
    return cab('Almoxarifado', 'Painel de controle') + msg() + `<section class="indicadores">${ind('Ativos registrados', IT.length, CAT.length + ' categorias · ' + setAtivos().length + ' setores')}${ind('Emprestados', ab.length, at.length + ' atrasados')}${ind('Solicitações', sol.length, 'aguardando aprovação', 1)}${ind('Manutenção', MAN.length, MAN.filter(x => x.et == 'c').length + ' a validar')}</section>
    <div class="painel-grade">${tab(['Setor', 'Item', 'OS', ''], sol.map(x => [nomeSetor(item(x.it)?.s), item(x.it)?.n || x.it, x.os, '<a class="btn-secundario" href="solicitacoes.php">Analisar</a>']))}
    ${atencao([['Reparo concluído', MAN.filter(x => x.et == 'c').map(x => x.n).join(', ') || 'Nenhum item aguardando validação.'], ['Devoluções atrasadas', at.length + ' empréstimo(s) com prazo vencido.'], ['Alerta de compra', cp.length + ' item(ns) descartado(s) aguardando a Diretoria.']])}</div>`;
  }
  return cab('Diretoria', 'Visão estratégica') + msg() + `<section class="indicadores">${ind('Ativos', IT.length, IT.filter(x => x.st == 'i').length + ' descartado(s)')}${ind('Emprestados', ab.length, 'em ' + setAtivos().length + ' setores')}${ind('Atrasados', at.length, 'sem bloqueio de setor', 1)}${ind('Pendências', ex.length + cp.length, ex.length + ' extensões · ' + cp.length + ' compra', 1)}</section>
  <div class="painel-grade"><div><p class="rotulo-mono" style="margin-bottom:8px">Uso por setor</p>${uso()}</div>${atencao([['Extensões de prazo', ex.length + ' pedido(s) aguardando decisão.'], ['Alertas de compra', cp.length + ' item(ns) descartado(s).'], ['Ir para', '<a href="aprovacoes.php">Aprovações</a>']])}</div>`;
};

R.catalogo = () => {
  const q = (Q.get('q') || '').toLowerCase(), L = vis().filter(x => (X.f == 'todos' || x.k == X.f) && (!X.s || x.s == X.s) && (!q || (x.c + x.n + (EMP[x.c] ? EMP[x.c][0] : '')).toLowerCase().includes(q)));
  const card = x => {
    let b = `<a class="btn-neutro" href="detalhe-equipamento.php?c=${x.c}">Ver detalhe</a>`;
    if (U.p == 'a' && x.st != 'i') b += ` <a class="btn-neutro" href="cadastros.php?e=${x.c}">Editar</a>`;
    if (U.p == 'g') b += x.st == 'd' ? ` <a class="btn-primario" href="nova-retirada.php?c=${x.c}">Solicitar retirada</a>` : (x.st == 'e' || x.st == 'a') ? ' <a class="btn-secundario" href="extensoes.php">Pedir extensão</a>' : ' <span class="btn-neutro" aria-disabled="true">Indisponível</span>';
    return `<div class="cartao card-eq${x.st == 'i' ? ' off' : ''}">${cod(x.c)}<h3>${x.n}</h3><p class="texto-ajuda">${CAT[x.k] || '—'} · ${nomeSetor(x.s)}</p>${sel(ST[x.st][0], ST[x.st][1])}${x.st == 'i' ? '<p class="texto-ajuda">Alerta de compra enviado à Diretoria.</p>' : ''}<div class="acoes">${b}</div></div>`;
  };
  return cab(`Catálogo · ${L.length} ativos${U.p == 'g' ? ' do setor' : ''}`, U.p == 'g' ? 'Equipamentos do meu setor' : 'Catálogo completo') + msg() + (U.p == 'a' ? '<p style="margin-bottom:14px"><a class="btn-primario" href="cadastros.php">+ Novo equipamento</a></p>' : '') + (U.p == 'd' ? `<div class="caixa-info msg">Visão somente leitura dos ${IT.length} ativos.</div>` : '')
    + pills([['todos', 'Todas as categorias'], ...CAT.map((c, i) => [i, c])], X.f, 'cat') + (U.p == 'g' ? '' : pills([['', 'Todos os setores'], ...setAtivos().map(k => [k, nomeSetor(k)])], X.s || '', 'set')) + `<div class="grade-cards">${L.map(card).join('')}</div>`;
};

R.detalhe = () => {
  const x = item(Q.get('c')); if (!x || (U.p == 'g' && x.s != U.s)) return cab('Catálogo', 'Equipamento não encontrado');
  const e = EMP[x.c], m = MAN.find(y => y.c == x.c), cp = COMPRA.find(y => y.it == x.c), xi = EXT.find(y => y.it == x.c && y.st == 'p'), g = U.p, H = hist(x);
  const f = (l, t) => `<div><p class="rotulo-mono">${l}</p><b>${t}</b></div>`, car = (t, b) => `<div class="cartao pad"><p class="rotulo-mono">${t}</p>${b}</div>`;
  let topo = '', c1, c2 = '';
  if (e) {
    const ex = { n: 'Não utilizada', p: 'Pendente na Diretoria · nova data ' + (xi ? xi.para : ''), u: 'Utilizada' }[e[2]];
    c1 = car('Empréstimo atual', `<div class="campos">${f('Setor solicitante', nomeSetor(x.s))}${f('Código do projeto / OS', e[0])}${f('Situação', sel(cor(e[3]), e[3]))}${f('Retirada', dmyh(e[6]))}${f('Prazo de devolução', dmyh(e[5]))}${f('Extensão de prazo', ex)}${f('Aprovado por', 'Almoxarifado')}</div>`);
    const t = { n: 'Nenhuma extensão pedida neste empréstimo. O pedido exige justificativa formal e passa pela Diretoria.', p: 'Pedido pendente na Diretoria para o dia ' + (xi ? xi.para : '') + '.', u: 'Extensão já utilizada. Não é possível pedir outra neste empréstimo.' }[e[2]];
    c2 = car('Extensão de prazo · 1 por empréstimo', `<p>${t}</p><div class="acoes">${g == 'g' && e[2] == 'n' ? '<a class="btn-primario" href="extensoes.php">Solicitar extensão de prazo</a>' : ''}${g == 'd' && xi ? btn('Aprovar', 'ext-ok', xi.id, 'btn-primario') + ' ' + btn('Recusar', 'ext-no', xi.id) : ''}</div>`);
    if (g == 'a') topo = `<a class="btn-primario" href="registrar-devolucao.php?c=${x.c}">Registrar devolução</a>`;
  } else if (m) {
    c1 = car('Manutenção atual', `<div class="campos">${f('Motivo', m.motivo)}${f('Enviado em', m.data)}${f('Etapa', sel(m.et == 'c' ? 'verde' : 'amarelo', m.et == 'c' ? 'Reparo concluído' : 'Em reparo'))}</div>${g == 'a' && m.et == 'c' ? '<div class="acoes">' + btn('Validar recebimento', 'validar', m.id, 'btn-primario') + '</div>' : ''}`);
  } else if (x.st == 'i') {
    c1 = car('Descarte', `<div class="campos">${f('Motivo', cp ? cp.motivo : '—')}${f('Compra', cp && cp.st == 'a' ? 'Autorizada' : 'Aguardando a Diretoria')}</div>${g == 'd' && cp && cp.st == 'p' ? '<div class="acoes">' + btn('Autorizar compra', 'compra', cp.id, 'btn-primario') + '</div>' : ''}`);
  } else {
    c1 = car('Empréstimo atual', '<p>Nenhum empréstimo em aberto.</p>');
    if (g == 'g' && x.st == 'd') topo = `<a class="btn-primario" href="nova-retirada.php?c=${x.c}">Solicitar retirada</a>`;
  }
  if (g == 'a' && x.st != 'i') topo += ` <a class="btn-neutro" href="cadastros.php?e=${x.c}">Editar cadastro</a>`;
  const n = r => H.filter(h => r(h)).length, mini = (n, t) => `<div class="mini"><b>${n}</b><br>${t}</div>`;
  const nExt = EXT.filter(y => y.it == x.c && y.st == 'ok').length;
  return `<p class="rotulo-mono migalhas"><a href="catalogo.php">Catálogo</a> / ${nomeSetor(x.s)} / ${x.n}</p>${cod(x.c)}${msg()}
  <div class="linha" style="justify-content:space-between;align-items:flex-start;margin:10px 0 16px"><div><h1 style="font-size:28px;margin-bottom:8px">${x.n}</h1><div class="linha">${sel(ST[x.st][0], ST[x.st][1])}${sel('cinza', CAT[x.k] || '—')}${sel('cinza', nomeSetor(x.s))}</div></div><div>${topo}</div></div>
  <div class="det-grid"><div>${c1}${c2}</div><div>${car('Indicadores do equipamento', `<div class="minis">${mini(H.length, 'empréstimos')}${mini(n(h => h[3] == 'man'), 'idas à manutenção')}${mini(n(h => h[3] == 'rep'), 'reposições simples')}${mini(nExt, 'extensões concedidas')}</div>`)}
  ${car('Ficha', `${f('Categoria', CAT[x.k] || '—')}<br>${f('Setor vinculado', nomeSetor(x.s))}<br>${f('Disponibilidade', x.st == 'd' ? '1 / 1' : '0 / 1')}<br>${f('Uso principal', x.uso)}`)}</div></div>
  <p class="rotulo-mono" style="margin:20px 0 8px">Histórico de movimentações</p>${tab(['Retirada', 'OS / projeto', 'Devolução', 'Destino na vistoria', 'Observações'], H.map(h => [h[0], cod(h[1]), h[2], sel(DS[h[3]][0], DS[h[3]][1]), h[4]]))}`;
};

R.emprestimos = () => {
  const L = vis().filter(x => EMP[x.c]).filter(x => X.f == 'todos' || (X.f == 'atr' ? x.st == 'a' : EMP[x.c][2] == 'p')), a = U.p == 'a';
  let pend = '';
  if (!a) { // o gestor acompanha, edita e cancela os pedidos que ainda aguardam o Almoxarifado
    const ed = SOL.find(s => s.id == X.edS);
    pend = `<p class="rotulo-mono" style="margin:22px 0 8px">Minhas solicitações aguardando o Almoxarifado · ${SOL.length}</p>`
      + tab(['Item', 'OS', 'Prazo previsto', ''], SOL.map(s => [cod(s.it) + '<br>' + (item(s.it)?.n || ''), s.os, s.pz, btn('Editar', 'sol-ed', s.id) + ' ' + btn('Cancelar pedido', 'sol-cancel', s.id)]))
      + (ed ? `<form id="f-sol-ed" class="cartao pad" style="margin-top:12px"><p class="rotulo-mono">Editar solicitação · ${ed.it}</p>${campo('Código do projeto / OS *', `<input class="input-texto" name="sol_os" value="${v('sol_os')}">`)}${campo('Prazo previsto de devolução *', `<input type="date" class="input-texto" name="sol_prazo" value="${v('sol_prazo')}">`)}<button class="btn-primario" type="submit">Salvar</button> ${btn('Cancelar edição', 'sol-ed-x', 0)}</form>` : '');
  }
  return cab(a ? 'Almoxarifado' : 'Meu setor', a ? 'Empréstimos ativos' : 'Meus empréstimos') + msg() + (a ? (IT.some(x => x.st == 'a') ? '<div class="caixa-info msg">Há empréstimos atrasados. Os setores continuam liberados para novas retiradas, mas a Diretoria acompanha cada atraso.</div>' : '') : '<div class="caixa-info msg">A devolução é feita em mãos ao Almoxarifado, que registra a vistoria.</div>')
    + pills([['todos', 'Todos'], ['atr', 'Atrasados'], ['ext', 'Extensão pendente']], X.f, 'filtro') + tab(['Item', ...(a ? ['Setor'] : []), 'OS', 'Prazo', 'Situação', ''], L.map(x => { const e = EMP[x.c]; return [cod(x.c) + '<br>' + x.n, ...(a ? [nomeSetor(x.s)] : []), e[0], e[1], sel(cor(e[3]), e[3]), a ? `<a class="btn-primario" href="registrar-devolucao.php?c=${x.c}">Registrar devolução</a>` : e[2] == 'n' ? '<a class="btn-neutro" href="extensoes.php">Pedir extensão</a>' : sel('cinza', e[2] == 'p' ? 'Extensão pendente' : 'Extensão usada')]; })) + pend;
};

R.solicitacoes = () => cab('Almoxarifado', 'Solicitações de retirada · ' + SOL.length + ' pendentes') + msg() + tab(['Setor', 'Item', 'OS/Projeto', 'Prazo previsto', 'Solicitante', 'Situação'], SOL.map(x => { const q = item(x.it); return [nomeSetor(q?.s), cod(x.it) + '<br>' + (q?.n || ''), x.os, x.pz, x.by, q && q.st == 'd' ? btn('Aprovar', 'aprovar', x.id, 'btn-primario') + ' ' + btn('Recusar', 'recusar', x.id) : btn('Recusar', 'recusar', x.id) + ' ' + sel('vermelho', 'Item indisponível')]; }));

R['nova-retirada'] = () => {
  const L = IT.filter(x => x.s == U.s), c = Q.get('c'); if (c && X.v[E(c)] === undefined && item(c)?.st == 'd') X.v[E(c)] = true;
  if (X.ok) return cab('Gestor', 'Nova retirada') + '<div class="caixa-info msg">Solicitação enviada ao Almoxarifado. O item só vira Emprestado depois da aprovação.</div><p><a class="btn-neutro" href="emprestimos.php">Acompanhar em Meus empréstimos</a></p>';
  const amanha = new Date(Date.now() + 864e5 - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  return cab('Gestor · solicitação de retirada', 'Nova retirada') + msg() + `<form id="f-ret" class="grade2"><div class="cartao pad"><p class="rotulo-mono">1 · Equipamentos do setor</p>${L.map(x => `<label class="linha-item"><input type="checkbox" name="${x.c}" ${x.st != 'd' ? 'disabled' : ''} ${X.v[x.c] && x.st == 'd' ? 'checked' : ''}> <span>${x.n}<br>${cod(x.c)} ${sel(ST[x.st][0], ST[x.st][1])}</span></label>`).join('')}</div>
  <div class="cartao pad"><p class="rotulo-mono">2 · Projeto e prazo</p><div class="campo-form"><label>Código do projeto / OS *</label><input class="input-texto" name="codigo_os" placeholder="OS-2026-0440" value="${v('codigo_os')}"></div><div class="campo-form"><label>Prazo previsto de devolução *</label><input type="date" class="input-texto" name="prazo_devolucao" min="${amanha}" value="${v('prazo_devolucao')}"></div>
  <label class="linha"><input type="checkbox" name="aceite_termo" ${X.v.aceite_termo ? 'checked' : ''}> <span class="texto-ajuda">Li e concordo com o termo digital de conservação e devolução no prazo.</span></label><p style="margin-top:14px"><button class="btn-primario" type="submit">Enviar ao Almoxarifado</button></p></div></form>`;
};

R.extensoes = () => {
  const meus = Object.keys(EMP).filter(c => item(c)?.s == U.s), lista = meus.filter(c => EMP[c][2] == 'n');
  const amanha = new Date(Date.now() + 864e5 - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  const meusPed = EXT.filter(x => item(x.it)?.s == U.s), ed = meusPed.find(x => x.id == X.edX && x.st == 'p');
  return cab('Meus empréstimos · prorrogação', 'Solicitar extensão de prazo') + msg() + `<div class="grade2"><form id="f-ext" class="cartao pad"><div class="caixa-info" style="margin-bottom:14px">Só é permitida 1 extensão por empréstimo. O pedido passa pela aprovação da Diretoria.</div>
  ${lista.length ? `<div class="campo-form"><label>Empréstimo ativo *</label><select class="input-texto" name="emp">${opts(lista.map(c => [EMP[c][4], `${c} · ${item(c).n} · prazo ${EMP[c][1]}`]), X.v.emp)}</select></div><div class="campo-form"><label>Nova data pretendida *</label><input type="date" class="input-texto" name="nova" min="${amanha}" value="${v('nova')}" required></div><div class="campo-form"><label>Justificativa formal *</label><textarea class="input-texto" name="just" required>${v('just')}</textarea></div><button class="btn-primario" type="submit">Enviar à Diretoria</button>` : '<p>Nenhum empréstimo disponível para extensão. <span class="texto-ajuda">Extensão já utilizada ou pendente.</span></p>'}</form>
  <div><p class="rotulo-mono" style="margin-bottom:8px">Histórico do setor</p>${tab(['Item', 'Situação'], meus.map(c => [item(c).n, sel({ n: 'cinza', p: 'amarelo', u: 'verde' }[EMP[c][2]], { n: 'Sem pedido', p: 'Pendente', u: 'Extensão já utilizada' }[EMP[c][2]])]))}</div></div>
  <p class="rotulo-mono" style="margin:22px 0 8px">Meus pedidos de extensão</p>${tab(['Item / OS', 'Prazo', 'Justificativa', 'Situação'], meusPed.map(x => [cod(x.it) + '<br>' + x.os, x.de + ' → ' + x.para, x.j, x.st == 'p' ? sel('amarelo', 'Pendente') + ' ' + btn('Editar', 'ext-ed', x.id) + ' ' + btn('Cancelar pedido', 'ext-cancel', x.id) : sel(x.st == 'ok' ? 'verde' : 'vermelho', x.st == 'ok' ? 'Aprovada' : 'Recusada')]))}
  ${ed ? `<form id="f-ext-ed" class="cartao pad" style="margin-top:12px"><p class="rotulo-mono">Editar pedido · ${ed.it}</p>${campo('Nova data pretendida *', `<input type="date" class="input-texto" name="xe_data" value="${v('xe_data')}" required>`)}${campo('Justificativa formal *', `<textarea class="input-texto" name="xe_just" required>${v('xe_just')}</textarea>`)}<button class="btn-primario" type="submit">Salvar</button> ${btn('Cancelar edição', 'ext-ed-x', 0)}</form>` : ''}`;
};

R.aprovacoes = () => {
  const ex = EXT.map(x => [(item(x.it)?.n || x.n) + '<br>' + nomeSetor(item(x.it)?.s) + ' · ' + x.os, x.de + ' → ' + x.para, x.j, x.st == 'p' ? btn('Aprovar', 'ext-ok', x.id, 'btn-primario') + ' ' + btn('Recusar', 'ext-no', x.id) : sel(x.st == 'ok' ? 'verde' : 'vermelho', x.st == 'ok' ? 'Aprovada' : 'Recusada')]);
  const cp = COMPRA.map(x => [x.n + '<br>' + cod(x.it), x.setor, x.motivo, x.st == 'p' ? btn('Autorizar compra', 'compra', x.id, 'btn-primario') : sel('verde', 'Compra autorizada')]);
  return cab('Diretoria · decisões pendentes', 'Aprovações') + msg() + pills([['x', `Extensões de prazo · ${EXT.filter(x => x.st == 'p').length}`], ['c', `Alertas de compra · ${COMPRA.filter(x => x.st == 'p').length}`]], X.t == 'c' ? 'c' : 'x', 'aba') + (X.t != 'c' ? tab(['Item / setor / OS', 'Prazo', 'Justificativa', ''], ex) : tab(['Item descartado', 'Setor', 'Motivo', ''], cp));
};

R.devolucao = () => {
  const c = Q.get('c') || '', x = item(c), e = EMP[E(c)], d = +(X.v.dest || 1);
  if (X.ok) return cab('Almoxarifado', 'Devolução registrada') + `<div class="caixa-info msg">${x ? x.n : ''}: status final <b>${x ? ST[x.st][1] : ''}</b>. <a href="emprestimos.php">Voltar aos empréstimos</a></div>`;
  if (!x || !e) return cab('Almoxarifado', 'Registrar devolução') + msg() + '<div class="caixa-info">Escolha um empréstimo em <a href="emprestimos.php">Empréstimos</a>.</div>';
  const DD = [['Íntegro ou reposição simples', 'Volta para Disponível', 'Insumo reposto (opcional)'], ['Dano técnico ou quebra', 'Vai para a oficina de Manutenção', 'Defeito identificado *'], ['Perda total ou desgaste irreversível', 'Descarta e gera alerta de compra', 'Motivo do descarte *']];
  const fim = ['Disponível. O item volta ao catálogo do setor na hora.', 'Em manutenção. O item vai para a oficina e depois volta ao Almoxarifado.', 'Descartado. A Diretoria recebe um alerta de compra.'];
  return `<p class="rotulo-mono migalhas"><a href="emprestimos.php">Empréstimos</a> / ${x.c}</p>` + cab(nomeSetor(x.s) + ' · ' + e[0], 'Registrar devolução') + msg() + `<div class="grade2"><div><div class="cartao pad"><p class="rotulo-mono">Empréstimo</p><p>${x.n} ${cod(x.c)}</p><p>Prazo: ${e[1]} · ${sel(cor(e[3]), e[3])}</p><p class="texto-ajuda">Condição inicial: ${x.cond == 'INTEGRO' ? 'Íntegro' : 'Com marcas de uso'}</p></div>
  <div class="cartao pad" style="margin-top:16px"><p class="rotulo-mono">Checklist de conservação</p>${CK.map((t, i) => `<label class="linha-item"><input type="checkbox" name="k${i}" ${X.v['k' + i] !== false ? 'checked' : ''}> ${t}</label>`).join('')}</div></div>
  <form id="f-dev" class="cartao pad"><p class="rotulo-mono">Destino na vistoria *</p>${DD.map((t, i) => `<label class="opcao${d == i + 1 ? ' ativo' : ''}"><input type="radio" name="dest" value="${i + 1}" ${d == i + 1 ? 'checked' : ''}> <b>${i + 1} · ${t[0]}</b><br><span class="texto-ajuda">${t[1]}</span></label>`).join('')}
  <div class="campo-form"><label>${DD[d - 1][2]}</label><input class="input-texto" name="det" value="${v('det')}"></div><div class="campo-form"><label>Observação</label><textarea class="input-texto" name="obs">${v('obs')}</textarea></div>
  <div class="caixa-info" style="margin-bottom:14px"><b>Status final:</b> ${fim[d - 1]}</div><button class="btn-primario" type="submit">Confirmar devolução</button></form></div>`;
};

R.manutencao = () => {
  const of = U.p == 'g', disp = IT.filter(x => x.st == 'd');
  return cab(of ? 'Oficina · Manutenção e Suporte' : 'Almoxarifado · itens fora da disponibilidade', of ? 'Oficina de manutenção' : 'Manutenção') + msg() + `<div class="linha" style="margin-bottom:16px">${['1 · Vistoria envia', '2 · Oficina repara', '3 · Almoxarifado valida', '4 · Disponível'].map(t => `<span class="filtro">${t}</span>`).join(' → ')}</div>`
    + tab(['Item', 'Motivo', 'Enviado em', 'Etapa', ''], MAN.map(m => [cod(m.c) + '<br>' + m.n, m.motivo, m.data, sel(m.et == 'of' ? 'amarelo' : 'verde', m.et == 'of' ? 'Em reparo' : 'Reparo concluído'), of ? (m.et == 'of' ? btn('Concluir reparo e devolver ao Almoxarifado', 'concluir', m.id, 'btn-primario') : sel('verde', 'Devolvido ao Almoxarifado')) : (m.et == 'c' ? btn('Validar recebimento', 'validar', m.id, 'btn-primario') : sel('amarelo', 'Na oficina') + ' ' + btn('Remover', 'man-del', m.id))]))
    + (of ? `<div class="cartao pad" style="margin-top:16px"><label class="rotulo-mono">Observação do reparo (ao concluir)</label><input class="input-texto" name="obs_reparo" value="${v('obs_reparo')}" placeholder="Ex.: substituída a porta Ethernet e testado o link"></div>`
      : `<p class="texto-ajuda" style="margin:12px 0">Ao validar o recebimento, o item volta a Disponível no catálogo do setor.</p>
      <form id="f-man" class="cartao pad"><p class="rotulo-mono">Enviar item disponível à manutenção</p>${campo('Equipamento *', `<select class="input-texto" name="man_eq">${opts(disp.map(x => [x.id, `${x.c} · ${x.n}`]), X.v.man_eq)}</select>`)}${campo('Defeito / motivo *', `<input class="input-texto" name="man_motivo" value="${v('man_motivo')}">`)}<button class="btn-primario" type="submit"${disp.length ? '' : ' disabled'}>Enviar à manutenção</button></form>`);
};

R.historico = () => {
  const L = HISR.map(h => {
    const aberto = h.destino_vistoria == 'ABERTO', e = EMP[E(h.codigo_patrimonio)], k = DEST[h.destino_vistoria];
    return { c: E(h.codigo_patrimonio), n: E(h.equipamento), s: h.setor_sigla, os: E(h.codigo_os), d: aberto ? (e ? e[1] : dm(h.prazo_devolucao)) : dm(h.devolvido_em), l: aberto && e ? e[3] : DS[k][1], k: aberto && e ? cor(e[3]) : DS[k][0] };
  });
  return cab(U.p == 'g' ? 'Movimentações do meu setor' : 'Todas as movimentações', 'Histórico de movimentações') + msg() + `<div class="linha" style="margin-bottom:14px">${U.p == 'g' ? '' : `<select class="input-texto" id="hs" style="width:200px"><option value="">Todos os setores</option>${opts(setAtivos().map(k => [k, nomeSetor(k)]), X.hs)}</select>`}<input class="input-texto" id="hq" style="width:260px" placeholder="Item ou OS" value="${E(X.hq || '')}"></div>`
    + `<div class="cartao"><table class="tabela" id="ht"><thead><tr><th>Item</th><th>Setor</th><th>OS</th><th>Prazo / devolução</th><th>Situação / destino</th></tr></thead><tbody>${L.map(r => `<tr data-s="${r.s}" data-t="${(r.c + r.n + r.os).toLowerCase()}"><td>${cod(r.c)}<br>${r.n}</td><td>${nomeSetor(r.s)}</td><td>${r.os}</td><td>${r.d}</td><td>${sel(r.k, r.l)}</td></tr>`).join('') || '<tr><td colspan="5">Nada por aqui.</td></tr>'}</tbody></table></div>`;
};

/* Cadastros (CRUD completo, só Almoxarifado) */
const CONF = { INTEGRO: 'Íntegro', COM_MARCAS_DE_USO: 'Com marcas de uso' };
R.cadastros = () => {
  const aba = pills([['x', 'Equipamentos'], ['c', 'Categorias'], ['u', 'Usuários'], ['s', 'Setores']], X.t, 'aba'), edit = X.ed != null; let b;
  const salvar = (t) => `<button class="btn-primario" type="submit">${edit ? 'Salvar alterações' : 'Salvar'}</button>${edit ? ' ' + btn('Cancelar edição', 'ed-x', 0) : ''}`;
  if (X.t == 'x') {
    const q = IT.find(x => x.id == X.ed);
    b = `<div class="grade2">${tab(['Código', 'Nome', 'Categoria', 'Setor', 'Status', ''], IT.map(x => [cod(x.c), x.n, CAT[x.k] || '—', nomeSetor(x.s), sel(ST[x.st][0], ST[x.st][1]), x.st == 'i' ? '' : btn('Editar', 'eq-ed', x.id) + ' ' + btn('Excluir', 'eq-del', x.id)]))}
    <form id="f-eq" class="cartao pad"><p class="rotulo-mono">${edit ? 'Editar equipamento · ' + (q ? q.c : '') : 'Novo equipamento'}</p>${campo('Nome *', `<input class="input-texto" name="eq_nome" value="${v('eq_nome')}">`)}
    ${campo('Categoria *', `<select class="input-texto" name="eq_cat">${opts(CATR.map(c => [c.id, E(c.nome)]), X.v.eq_cat)}</select>`)}
    ${campo('Setor vinculado *', `<select class="input-texto" name="eq_set">${opts(setAtivos().map(k => [SET[k][2], SET[k][0]]), X.v.eq_set)}</select>`)}
    <div class="campo-form"><label>Código de patrimônio *</label><input class="input-texto" id="cod" name="eq_cod" placeholder="NOTE-DEV-007" value="${v('eq_cod')}"><div class="erro" id="dup" style="display:none;margin-top:8px">Este código de patrimônio já está cadastrado.</div></div>
    ${campo('Condição inicial *', `<select class="input-texto" name="eq_cond">${opts(Object.entries(CONF), X.v.eq_cond)}</select>`)}
    ${campo('Uso principal', `<input class="input-texto" name="eq_uso" value="${v('eq_uso')}">`)}${salvar()}</form></div>`;
  } else if (X.t == 'c') {
    b = `<div class="grade2">${tab(['Categoria', 'Itens', ''], CATR.map(c => [E(c.nome), c.itens, btn('Editar', 'ct-ed', c.id) + ' ' + (+c.itens ? '<span class="texto-ajuda">Exclusão bloqueada: há itens</span>' : btn('Excluir', 'ct-del', c.id))]))}
    <form id="f-ct" class="cartao pad"><p class="rotulo-mono">${edit ? 'Renomear categoria' : 'Nova categoria'}</p>${campo('Nome *', `<input class="input-texto" name="ct_nome" value="${v('ct_nome')}">`)}${salvar()}</form></div>`;
  } else if (X.t == 'u') {
    b = `<div class="grade2">${tab(['Nome', 'E-mail', 'Perfil', 'Setor', 'Situação', ''], USERS.map(u => [E(u.nome), E(u.email), { ALMOXARIFADO: 'Almoxarifado', GESTOR: 'Gestor', DIRETORIA: 'Diretoria' }[u.perfil], E(u.setor || '—'), +u.ativo ? sel('verde', 'Ativo') : sel('cinza', 'Inativo'), btn('Editar', 'us-ed', u.id) + (u.id == U.id ? '' : ' ' + btn('Excluir', 'us-del', u.id))]))}
    <form id="f-us" class="cartao pad"><p class="rotulo-mono">${edit ? 'Editar usuário' : 'Novo usuário'}</p>${campo('Nome *', `<input class="input-texto" name="us_nome" value="${v('us_nome')}">`)}${campo('E-mail *', `<input type="email" class="input-texto" name="us_email" value="${v('us_email')}">`)}
    ${campo('Perfil *', `<select class="input-texto" name="us_perf">${opts([['g', 'Gestor'], ['a', 'Almoxarifado'], ['d', 'Diretoria']], X.v.us_perf || 'g')}</select>`)}
    <div class="campo-form" id="usetor" style="${(X.v.us_perf || 'g') == 'g' ? '' : 'display:none'}"><label>Setor *</label><select class="input-texto" name="us_set">${opts(setAtivos().map(k => [SET[k][2], SET[k][0]]), X.v.us_set)}</select></div>
    ${campo(edit ? 'Nova senha (deixe em branco para manter)' : 'Senha inicial * (mín. 8 caracteres)', `<input type="password" class="input-texto" name="us_senha" autocomplete="new-password" value="${v('us_senha')}">`)}
    ${edit ? `<label class="linha"><input type="checkbox" name="us_ativo" ${X.v.us_ativo !== false ? 'checked' : ''}> <span class="texto-ajuda">Usuário ativo (desativar bloqueia o acesso e mantém o histórico)</span></label><br>` : ''}${salvar()}</form></div>`;
  } else {
    b = `<div class="grade2">${tab(['Sigla', 'Nome', 'Itens', 'Situação', ''], SETR.map(s => [E(s.sigla), E(s.nome), s.equipamentos, +s.ativo ? sel('verde', 'Ativo') : sel('cinza', 'Inativo'), btn('Editar', 'se-ed', s.id) + ' ' + btn('Excluir', 'se-del', s.id)]))}
    <form id="f-se" class="cartao pad"><p class="rotulo-mono">${edit ? 'Editar setor' : 'Novo setor'}</p>${campo('Sigla * (ex.: dev)', `<input class="input-texto" name="se_sigla" maxlength="10" value="${v('se_sigla')}">`)}${campo('Nome completo *', `<input class="input-texto" name="se_nome" value="${v('se_nome')}">`)}${campo('Nome curto *', `<input class="input-texto" name="se_curto" maxlength="30" value="${v('se_curto')}">`)}
    ${edit ? `<label class="linha"><input type="checkbox" name="se_ativo" ${X.v.se_ativo !== false ? 'checked' : ''}> <span class="texto-ajuda">Setor ativo</span></label><br>` : ''}${salvar()}</form></div>`;
  }
  return cab('Cadastros · somente Almoxarifado', 'Cadastros') + msg() + aba + b;
};

R.setores = () => {
  const k = SET[X.s] ? X.s : setAtivos()[0], L = nSet(k);
  return cab('Setores / perfil · centro de custo', SET[k][0]) + msg() + pills(setAtivos().map(s => [s, nomeSetor(s)]), k, 'setor') + `<section class="indicadores">${ind('Equipamentos', L.length, 'vinculados')}${ind('Emprestados', L.filter(x => EMP[x.c]).length, 'agora')}${ind('Atrasos', L.filter(x => x.st == 'a').length, 'sem bloqueio do setor', 1)}${ind('Em manutenção', L.filter(x => x.st == 'm').length, 'agora')}</section>` + tab(['Equipamento', 'Status', 'OS atual'], L.map(x => [cod(x.c) + '<br>' + x.n, sel(ST[x.st][0], ST[x.st][1]), EMP[x.c] ? EMP[x.c][0] : '—']));
};

/* ---------- ações (botões com data-a) ---------- */
const lim = () => { X.v = {}; X.ed = null; };
const A = {
  perfil: i => { X.v.perfil = i; },
  cat: i => { X.f = i == 'todos' ? i : +i; }, set: i => { X.s = i; }, filtro: i => { X.f = i; }, setor: i => { X.s = i; },
  aba: i => { X.t = i; lim(); },
  aprovar: i => exec('retirada_aprovar', { id: +i }),
  recusar: i => { const m = prompt('Motivo da recusa (opcional):'); if (m === null) return; return exec('retirada_recusar', { id: +i, motivo: m }); },
  'ext-ok': i => exec('extensao_decidir', { id: +i, aprovar: true }),
  'ext-no': i => exec('extensao_decidir', { id: +i, aprovar: false }),
  compra: i => exec('compra_autorizar', { id: +i }),
  concluir: i => exec('manutencao_concluir', { id: +i, observacao: X.v.obs_reparo || '' }, () => { X.v.obs_reparo = ''; }),
  validar: i => exec('manutencao_validar', { id: +i }),
  'man-del': i => { if (confirm('Remover este item da manutenção? Ele volta a Disponível.')) return exec('manutencao_excluir', { id: +i }); },
  'sol-cancel': i => { if (confirm('Cancelar esta solicitação de retirada?')) return exec('retirada_cancelar', { id: +i }); },
  'sol-ed': i => { const s = SOL.find(y => y.id == i); X.edS = +i; X.v.sol_os = s.os; X.v.sol_prazo = s.pzv; },
  'sol-ed-x': () => { X.edS = null; },
  'ext-cancel': i => { if (confirm('Cancelar este pedido de extensão? Depois você poderá fazer outro.')) return exec('extensao_cancelar', { id: +i }); },
  'ext-ed': i => { const x = EXT.find(y => y.id == i); X.edX = +i; X.v.xe_data = x.parav; X.v.xe_just = x.jraw; },
  'ext-ed-x': () => { X.edX = null; },
  'ed-x': () => lim(),
  'eq-ed': i => { const q = IT.find(y => y.id == i); X.ed = q.id; X.v = { eq_nome: q.nr, eq_cat: q.cid, eq_set: q.sid, eq_cod: q.c, eq_cond: q.cond, eq_uso: q.usoRaw }; scrollTo(0, 0); },
  'eq-del': i => { const q = IT.find(y => y.id == i); if (confirm('Excluir o equipamento ' + q.c + '? Só é possível se ele nunca teve movimentação.')) return exec('equipamento_excluir', { id: +i }); },
  'ct-ed': i => { const c = CATR.find(y => y.id == i); X.ed = c.id; X.v = { ct_nome: c.nome }; },
  'ct-del': i => { if (confirm('Excluir esta categoria?')) return exec('categoria_excluir', { id: +i }); },
  'us-ed': i => { const u = USERS.find(y => y.id == i); X.ed = u.id; X.v = { us_nome: u.nome, us_email: u.email, us_perf: { ALMOXARIFADO: 'a', GESTOR: 'g', DIRETORIA: 'd' }[u.perfil], us_set: u.setor_id || SET[setAtivos()[0]][2], us_ativo: !!+u.ativo }; },
  'us-del': i => { const u = USERS.find(y => y.id == i); if (confirm('Excluir o usuário ' + u.nome + '? Se ele tiver histórico, o banco bloqueia: desative-o em vez disso.')) return exec('usuario_excluir', { id: +i }); },
  'se-ed': i => { const s = SETR.find(y => y.id == i); X.ed = s.id; X.v = { se_sigla: s.sigla, se_nome: s.nome, se_curto: s.nome_curto, se_ativo: !!+s.ativo }; },
  'se-del': i => { const s = SETR.find(y => y.id == i); if (confirm('Excluir o setor ' + s.nome_curto + '? Só é possível se não tiver equipamentos nem usuários.')) return exec('setor_excluir', { id: +i }); }
};
document.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (b) { const r = A[b.dataset.a](b.dataset.i); if (!(r instanceof Promise)) { X.err = ''; draw(); } } });
document.addEventListener('input', e => {
  const t = e.target; if (t.closest('#app') && (t.name || t.id == 'hq' || t.id == 'hs')) X.dirty = true;
  if (t.name) X.v[t.name] = t.type == 'checkbox' ? t.checked : t.value;
  if (t.id == 'setor') $('#email').value = MAIL[t.value] + '@techrental.com';
  if (t.id == 'hq' || t.id == 'hs') { X[t.id] = t.value; X.dirty = false; filtrar(); }
  if (t.id == 'cod') { const d = IT.some(x => x.c.toLowerCase() == t.value.trim().toLowerCase() && x.id != X.ed); $('#dup').style.display = d ? 'block' : 'none'; }
  if (t.name == 'us_perf') $('#usetor').style.display = t.value == 'g' ? '' : 'none';
  if (t.name == 'dest') { X.dirty = false; draw(); }
});
function filtrar() { const q = $('#hq').value.toLowerCase(), s = $('#hs') ? $('#hs').value : ''; document.querySelectorAll('#ht tbody tr').forEach(r => { r.style.display = (!q || (r.dataset.t || '').includes(q)) && (!s || r.dataset.s == s) ? '' : 'none'; }); }

document.addEventListener('submit', async e => {
  e.preventDefault(); const f = e.target.id, fd = Object.fromEntries(new FormData(e.target)); X.err = '';
  if (f == 'f-login') { // valida e-mail e senha no servidor (login.php), que abre a sessão
    fetch('login.php', { method: 'POST', body: new URLSearchParams({ email: $('#email').value, senha: $('#senha').value }) })
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => { if (!d.ok) throw 0; location = 'painel.php'; })
      .catch(() => { location.search = '?erro=1'; });
    return;
  }
  if (f == 'f-ret') {
    const codigos = IT.filter(x => x.s == U.s && x.st == 'd' && X.v[x.c]).map(x => x.c);
    const r = await exec('retirada_solicitar', { codigos, codigo_os: fd.codigo_os, prazo: fd.prazo_devolucao, aceite: !!fd.aceite_termo }, () => { X.ok = 1; X.v = {}; }); return r;
  }
  if (f == 'f-sol-ed') return exec('retirada_editar', { id: X.edS, codigo_os: fd.sol_os, prazo: fd.sol_prazo }, () => { X.edS = null; X.v = {}; });
  if (f == 'f-ext') return exec('extensao_solicitar', { emprestimo_id: +fd.emp, novo_prazo: fd.nova, justificativa: fd.just }, () => { X.v = {}; });
  if (f == 'f-ext-ed') return exec('extensao_editar', { id: X.edX, novo_prazo: fd.xe_data, justificativa: fd.xe_just }, () => { X.edX = null; X.v = {}; });
  if (f == 'f-dev') {
    const c = Q.get('c'), e1 = EMP[E(c)], dd = +(X.v.dest || 1);
    const ck = CK.map((_, i) => i + 1).filter(i => X.v['k' + (i - 1)] !== false);
    return exec('devolucao', { id: e1 ? e1[4] : 0, destino: ['DISPONIVEL', 'MANUTENCAO', 'DESCARTE'][dd - 1], detalhe: fd.det, observacao: fd.obs, checklist: ck }, () => { X.ok = 1; });
  }
  if (f == 'f-man') return exec('manutencao_abrir', { equipamento_id: +fd.man_eq, motivo: fd.man_motivo }, () => { X.v = {}; });
  if (f == 'f-eq') {
    const d = { codigo: fd.eq_cod, nome: fd.eq_nome, categoria_id: +fd.eq_cat, setor_id: +fd.eq_set, condicao: fd.eq_cond, uso: fd.eq_uso };
    return exec(X.ed != null ? 'equipamento_atualizar' : 'equipamento_criar', X.ed != null ? { ...d, id: X.ed } : d, lim);
  }
  if (f == 'f-ct') return exec(X.ed != null ? 'categoria_atualizar' : 'categoria_criar', { id: X.ed, nome: fd.ct_nome }, lim);
  if (f == 'f-us') return exec(X.ed != null ? 'usuario_atualizar' : 'usuario_criar', { id: X.ed, nome: fd.us_nome, email: fd.us_email, perfil: fd.us_perf, setor_id: +(fd.us_set || 0), senha: fd.us_senha, ativo: X.ed != null ? !!fd.us_ativo : true }, lim);
  if (f == 'f-se') return exec(X.ed != null ? 'setor_atualizar' : 'setor_criar', { id: X.ed, sigla: fd.se_sigla, nome: fd.se_nome, nome_curto: fd.se_curto, ativo: X.ed != null ? !!fd.se_ativo : true }, lim);
});

/* ---------- desenha a página ---------- */
function draw() {
  const app = $('#app');
  X.dirty = false; X.pend = false;
  if (P == 'login') { app.innerHTML = R.login(); return; }
  let html = R[P]();
  if (X.err && !html.includes('class="erro"')) html = html.replace('</h1></div>', '</h1></div><div class="erro">' + E(X.err) + '</div>');
  app.innerHTML = nav() + '<main class="conteudo">' + html + '</main>';
  $('#sair').onclick = ev => { ev.preventDefault(); fetch('api.php?a=sair', { method: 'POST' }).finally(() => { location = 'login.php'; }); };
  X.m = ''; X.err = '';
}

/* ---------- tempo real: confere o banco a cada poucos segundos ---------- */
const emEdicao = () => { const a = document.activeElement; return X.dirty || (a && a.closest && a.closest('#app') && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type != 'checkbox' && a.type != 'radio'); };
function aovivo(ok) { const el = $('#aovivo'); if (el) { el.classList.toggle('off', !ok); el.lastChild.textContent = ok ? 'ao vivo' : 'sem conexão'; } }
async function carregar(forcar) {
  try {
    const r = await fetch('api.php?a=estado&h=' + (forcar ? '' : HASH), { cache: 'no-store' });
    if (r.status == 401) { location = 'login.php'; return false; }
    const j = await r.json(); aovivo(true);
    if (!j.mudou) return true;
    aplicar(j);
    if (forcar || !emEdicao()) draw(); else X.pend = true; // não atropela quem está digitando
    return true;
  } catch (err) { aovivo(false); return false; }
}
function ciclo() { setTimeout(async () => { if (!document.hidden) await carregar(false); ciclo(); }, 3000); }
document.addEventListener('visibilitychange', () => { if (!document.hidden) carregar(false); });
document.addEventListener('focusout', () => setTimeout(() => { if (X.pend && !emEdicao()) carregar(true); }, 50));

(async function iniciar() {
  if (P == 'login') { draw(); return; }
  if (!(await carregar(true))) return;
  if (!(MENU[U.p].some(m => m[1] == P) || P == 'detalhe' || (P == 'devolucao' && U.p == 'a') || (P == 'manutencao' && U.p == 'g' && U.s == 'ms'))) { location = 'painel.php'; return; }
  if (P == 'cadastros' && Q.get('e')) { const q = item(Q.get('e')); if (q) { A['eq-ed'](q.id); draw(); } }
  ciclo();
})();
