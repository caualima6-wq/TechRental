<?php
// Configuração de acesso ao banco (versão para XAMPP local: usuário root, sem senha).
return [
    'host' => getenv('TR_DB_HOST') ?: '127.0.0.1',
    'port' => getenv('TR_DB_PORT') ?: '3306',   // se o MySQL do XAMPP usar outra porta (ex.: 3307), troque aqui
    'name' => getenv('TR_DB_NAME') ?: 'techrental',
    'user' => getenv('TR_DB_USER') ?: 'root',
    'pass' => getenv('TR_DB_PASS') ?: '',
    'tz'   => getenv('TR_DB_TZ')   ?: '-03:00',
];
