<?php
// Conexão PDO, sessão PHP e utilitários de resposta JSON. Incluído por login.php e api.php.
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

session_name('techrental');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

function responder(int $codigo, array $dados): void {
    http_response_code($codigo);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function pdo(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = require __DIR__ . '/config.php';
    try {
        $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4, time_zone = '{$c['tz']}'",
        ]);
    } catch (Throwable $e) {
        error_log('TechRental: falha ao conectar no banco: ' . $e->getMessage());
        $local = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
        responder(503, ['ok' => false, 'erro' => 'Banco de dados indisponível. Tente novamente em instantes.'] + ($local ? ['detalhe' => $e->getMessage()] : []));
    }
    return $pdo;
}

/** Executa um SELECT/CALL e devolve TODOS os result sets: [[linhas do 1º], [linhas do 2º], ...] */
function consultar(string $sql, array $params = []): array {
    $st = pdo()->prepare($sql);
    $st->execute($params);
    $sets = [];
    do {
        if ($st->columnCount() > 0) $sets[] = $st->fetchAll();
    } while ($st->nextRowset());
    $st->closeCursor();
    return $sets;
}

/** CALL sp_xxx(?, ?, ...) e devolve as linhas do primeiro result set */
function chamar(string $proc, array $params = []): array {
    $marcas = implode(',', array_fill(0, count($params), '?'));
    return consultar("CALL $proc($marcas)", $params)[0] ?? [];
}

/** Mensagens de regra de negócio (SQLSTATE 45000) vão para o usuário; o resto é log + mensagem genérica. */
function tratar_erro(Throwable $e): void {
    if ($e instanceof PDOException) {
        $estado = (string)($e->errorInfo[0] ?? $e->getCode());
        $msg = (string)($e->errorInfo[2] ?? '');
        if ($estado === '45000' && $msg !== '') responder(422, ['ok' => false, 'erro' => $msg]);
        error_log('TechRental SQL: ' . $e->getMessage());
        responder(500, ['ok' => false, 'erro' => 'Não foi possível concluir a operação. Confira os dados e tente de novo.']);
    }
    error_log('TechRental: ' . $e->getMessage());
    responder(500, ['ok' => false, 'erro' => 'Erro interno.']);
}

function usuario_logado(): ?array {
    return $_SESSION['u'] ?? null;
}
