<?php
// Diagnóstico temporário: apague este arquivo depois de resolver.
header('Content-Type: text/plain; charset=utf-8');
$c = require __DIR__ . '/api/config.php';
echo "Tentando: {$c['user']}@{$c['host']}:{$c['port']} banco '{$c['name']}'\n\n";
echo "PHP " . PHP_VERSION . " | pdo_mysql: " . (extension_loaded('pdo_mysql') ? 'ativo' : 'DESATIVADO') . "\n\n";
try {
    $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};charset=utf8mb4", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    echo "1) Conexão com o MySQL: OK\n";
    $bancos = $pdo->query('SHOW DATABASES')->fetchAll(PDO::FETCH_COLUMN);
    echo "2) Banco '{$c['name']}' existe: " . (in_array($c['name'], $bancos) ? 'sim' : 'NÃO (importe banco/techrental_completo.sql no phpMyAdmin)') . "\n";
    if (in_array($c['name'], $bancos)) {
        $pdo->exec("USE `{$c['name']}`");
        echo "3) Usuários cadastrados: " . $pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn() . "\n";
        $st = $pdo->query("CALL sp_usuario_login('gestor.software@techrental.com')");
        $r = $st->fetchAll(PDO::FETCH_ASSOC);
        $st->closeCursor();
        echo "4) gestor.software encontrado: " . (count($r) ? 'sim' : 'NÃO') . "\n";
        if ($r) echo "5) Senha 12345678 confere com o hash: " . (password_verify('12345678', $r[0]['senha_hash']) ? 'sim' : 'NÃO') . "\n";
    }
} catch (Throwable $e) {
    echo "ERRO: " . $e->getMessage() . "\n";
}
