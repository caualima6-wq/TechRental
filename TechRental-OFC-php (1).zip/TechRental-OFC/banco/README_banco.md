# TechRental · Banco de dados MySQL

Requisitos: **MySQL 8.0.16 ou superior** (usa CHECK, JSON_TABLE e colunas geradas).
Testado em MySQL 8.0.46: carga completa + 80 testes automáticos, 0 falhas.

## Como instalar

```bash
mysql -u root -p < techrental_completo.sql      # cria o banco, as regras e os dados do protótipo
mysql -u root -p < techrental_testes_crud.sql   # (opcional) roda os 80 testes; altera dados!
```

> A primeira linha do script faz `DROP DATABASE IF EXISTS techrental`. Isso é para desenvolvimento.
> Remova-a antes de usar com dados reais. Depois dos testes, rode `techrental_completo.sql` de novo.

Logins de teste (senha **12345678**, os mesmos hashes do `login.php`):
`almoxarifado@`, `gestor.software@`, `gestor.pd@`, `gestor.campo@`, `gestor.suporte@`, `diretoria@` + `techrental.com`.

## Modelo (11 tabelas)

```mermaid
erDiagram
  setores ||--o{ usuarios : "gestor pertence a"
  setores ||--o{ equipamentos : "vinculado a"
  categorias ||--o{ equipamentos : classifica
  equipamentos ||--o{ emprestimos : "é emprestado"
  usuarios ||--o{ emprestimos : "solicita / aprova"
  emprestimos ||--o| extensoes_prazo : "no máx. 1"
  emprestimos ||--o| devolucoes : "vistoria"
  devolucoes ||--o{ devolucao_checklist : confere
  checklist_itens ||--o{ devolucao_checklist : ""
  equipamentos ||--o{ manutencoes : "vai para"
  devolucoes ||--o{ manutencoes : "origina"
  equipamentos ||--o| alertas_compra : "descarte gera"
  devolucoes ||--o{ alertas_compra : "origina"
```

Ciclo do empréstimo: `PENDENTE → ATIVO → DEVOLVIDO` (ou `RECUSADO` / `CANCELADO`).
Ciclo do equipamento: `DISPONIVEL → EMPRESTADO → DISPONIVEL | MANUTENCAO | DESCARTADO`.

## Regras que o banco garante (mesmo se alguém escrever SQL direto)

| Regra | Como é garantida |
|---|---|
| Gestor sempre tem setor; Almoxarifado e Diretoria não | CHECK em `usuarios` |
| Só equipamento disponível pode ser solicitado, e só pelo gestor do próprio setor | trigger em `emprestimos` |
| 1 empréstimo ativo por equipamento | coluna gerada + UNIQUE |
| 1 pedido de extensão por empréstimo (recusada também conta como usada) | UNIQUE em `extensoes_prazo.emprestimo_id` |
| Extensão exige justificativa e nova data posterior ao prazo | CHECK |
| Só a Diretoria decide extensão e autoriza compra; só o Almoxarifado devolve e valida | triggers + procedures |
| 1 manutenção em aberto por equipamento | coluna gerada + UNIQUE |
| Defeito/motivo obrigatório na devolução com destino Manutenção ou Descarte | CHECK + procedure |
| Categoria, setor e usuário com vínculos não podem ser excluídos | procedures com mensagem clara |
| Atraso **não** bloqueia novas retiradas | não existe trava de atraso |

**"Atrasado" não é gravado.** É calculado nas views (empréstimo ativo com prazo vencido), então nunca fica desatualizado.
Por isso o número de atrasados que você vê hoje difere do protótipo: os dados de exemplo têm as datas do protótipo (9/11/2026) e o banco compara com a data real.

## CRUD por entidade

| Entidade | Criar | Listar | Obter | Atualizar | Excluir |
|---|---|---|---|---|---|
| Setores | `sp_setor_criar` | `sp_setor_listar` | `sp_setor_obter` | `sp_setor_atualizar` | `sp_setor_excluir` |
| Categorias | `sp_categoria_criar` | `sp_categoria_listar` | `sp_categoria_obter` | `sp_categoria_atualizar` | `sp_categoria_excluir` |
| Usuários | `sp_usuario_criar` | `sp_usuario_listar` | `sp_usuario_obter` | `sp_usuario_atualizar`, `sp_usuario_alterar_senha` | `sp_usuario_excluir` |
| Equipamentos | `sp_equipamento_criar` | `sp_equipamento_listar` | `sp_equipamento_obter` | `sp_equipamento_atualizar` | `sp_equipamento_excluir` |
| Empréstimos | `sp_emprestimo_solicitar` | `sp_emprestimo_listar` | `sp_emprestimo_obter` | `sp_emprestimo_atualizar` | `sp_emprestimo_cancelar`, `sp_emprestimo_excluir` |
| Extensões | `sp_extensao_solicitar` | `sp_extensao_listar` | `sp_extensao_obter` | `sp_extensao_atualizar` | `sp_extensao_excluir` |
| Manutenções | `sp_manutencao_abrir` | `sp_manutencao_listar` | `sp_manutencao_obter` | `sp_manutencao_atualizar` | `sp_manutencao_excluir` |
| Alertas de compra | `sp_compra_registrar` | `sp_compra_listar` | `sp_compra_obter` | `sp_compra_atualizar` | `sp_compra_excluir` |

Ações de fluxo (cada uma em transação): `sp_emprestimo_aprovar`, `sp_emprestimo_recusar`,
`sp_emprestimo_registrar_devolucao`, `sp_extensao_decidir`, `sp_manutencao_concluir`,
`sp_manutencao_validar`, `sp_compra_autorizar`, `sp_historico_listar`.

Exclusão segue o negócio: o que já virou histórico (empréstimo ativo/devolvido, extensão decidida, manutenção validada, compra autorizada, equipamento com movimentação) **não é apagado**. Equipamento sai de circulação pelo descarte, usuário por `ativo = 0`.

## De qual tela vem cada dado

| Tela | Banco |
|---|---|
| Login | `sp_usuario_login`, `sp_usuario_registrar_login` |
| Painel | `vw_indicadores_gerais`, `vw_indicadores_setor`, `vw_solicitacoes_pendentes`, `vw_emprestimos_ativos` |
| Catálogo / Detalhe | `sp_equipamento_listar` / `sp_equipamento_obter` (ficha, histórico e indicadores) |
| Nova retirada | `sp_emprestimo_solicitar` (vários códigos num JSON: `'["NOTE-DEV-002","SRV-DEV-005"]'`) |
| Solicitações | `vw_solicitacoes_pendentes` + `sp_emprestimo_aprovar` / `sp_emprestimo_recusar` |
| Empréstimos | `vw_emprestimos_ativos` |
| Extensões / Aprovações | `sp_extensao_solicitar` / `vw_extensoes_pendentes` + `sp_extensao_decidir`; `vw_alertas_compra` + `sp_compra_autorizar` |
| Registrar devolução | `sp_emprestimo_registrar_devolucao` (checklist em JSON: `'[1,2,3,4,5]'`) |
| Manutenção / Oficina | `sp_manutencao_listar`, `sp_manutencao_concluir`, `sp_manutencao_validar` |
| Histórico | `sp_historico_listar` |
| Cadastros / Setores | procedures de CRUD acima, `sp_setor_obter` |

## Ligando o `login.php` ao banco

Hoje o `login.php` tem os usuários fixos no código. Com o banco, ele passa a consultar `sp_usuario_login`
(devolve `p` e `s` nos mesmos códigos que o `app.js` já usa: `a`/`g`/`d` e `dev`/`pd`/`cp`/`ms`).
Esse trecho **não foi executado** (não testei PHP aqui), só o lado SQL:

```php
$pdo = new PDO('mysql:host=localhost;dbname=techrental;charset=utf8mb4', 'techrental_app', 'SENHA_DO_BANCO',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);

$st = $pdo->prepare('CALL sp_usuario_login(?)');
$st->execute([$email]);
$u = $st->fetch(PDO::FETCH_ASSOC);
$st->closeCursor();

$hash = $u['senha_hash'] ?? '$2y$10$usesomesillystringforsalt.abcdefghijklmnopqrstuv';
$ok = password_verify($senha, $hash) && $u;           // mantém o truque anti-timing atual
// se $ok: $pdo->prepare('CALL sp_usuario_registrar_login(?)')->execute([$u['id']]);
//         echo json_encode(['ok' => true, 'p' => $u['p'], 's' => $u['s']]);
```

Crie um usuário do banco só para o sistema (nunca use o `root` no PHP):

```sql
CREATE USER 'techrental_app'@'localhost' IDENTIFIED BY 'TROQUE_ESTA_SENHA';
GRANT SELECT, EXECUTE ON techrental.* TO 'techrental_app'@'localhost';
```

## Importante para o back end

As procedures conferem o **perfil** pelo id do usuário que você passa (por exemplo, só `ALMOXARIFADO` aprova).
Hoje o protótipo guarda o perfil apenas no `sessionStorage` do navegador, o que qualquer pessoa consegue alterar.
Ao ligar o sistema ao banco, o `login.php` deve abrir uma **sessão PHP** com o id do usuário, e os demais endpoints
devem usar o id dessa sessão, nunca um id vindo do navegador.
