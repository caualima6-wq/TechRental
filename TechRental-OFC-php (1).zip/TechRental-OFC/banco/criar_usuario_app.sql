-- Usuário do banco usado só pelo sistema (api/config.php). Troque a senha antes de usar em produção.
CREATE USER IF NOT EXISTS 'techrental_app'@'localhost' IDENTIFIED BY 'TROQUE_ESTA_SENHA';
CREATE USER IF NOT EXISTS 'techrental_app'@'127.0.0.1' IDENTIFIED BY 'TROQUE_ESTA_SENHA';
GRANT SELECT, EXECUTE ON techrental.* TO 'techrental_app'@'localhost';
GRANT SELECT, EXECUTE ON techrental.* TO 'techrental_app'@'127.0.0.1';
FLUSH PRIVILEGES;
