-- =====================================================================
-- TechRental · 05 · Testes de CRUD e de regras de negócio
-- Rode em um banco de TESTE (ele altera os dados). Para voltar ao estado inicial,
-- rode de novo 01, 02, 03 e 04. No final, a última tabela mostra OK/FALHOU por teste.
-- (Os resultados intermediários das procedures também aparecem; ignore-os.)
-- =====================================================================
USE techrental;
SET NAMES utf8mb4;

DROP TEMPORARY TABLE IF EXISTS t_resultados;
CREATE TEMPORARY TABLE t_resultados (n INT AUTO_INCREMENT PRIMARY KEY, teste VARCHAR(200), resultado VARCHAR(300));

DROP PROCEDURE IF EXISTS t_afirmar;
DROP PROCEDURE IF EXISTS t_erro;
DELIMITER $$
CREATE PROCEDURE t_afirmar(IN p_teste VARCHAR(200), IN p_ok TINYINT(1))
BEGIN
  INSERT INTO t_resultados (teste, resultado) VALUES (p_teste, IF(p_ok = 1, 'OK', 'FALHOU'));
END$$
-- Executa um CALL esperando que ele FALHE com mensagem contendo p_trecho
CREATE PROCEDURE t_erro(IN p_teste VARCHAR(200), IN p_sql TEXT, IN p_trecho VARCHAR(120))
BEGIN
  DECLARE v_msg TEXT DEFAULT NULL;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION GET DIAGNOSTICS CONDITION 1 v_msg = MESSAGE_TEXT;
  SET @t_sql = p_sql;
  PREPARE t_st FROM @t_sql; EXECUTE t_st; DEALLOCATE PREPARE t_st;
  INSERT INTO t_resultados (teste, resultado)
  VALUES (p_teste, IF(v_msg IS NOT NULL AND v_msg LIKE CONCAT('%', p_trecho, '%'), 'OK', CONCAT('FALHOU (', COALESCE(v_msg,'sem erro'), ')')));
END$$
DELIMITER ;

SET @almox = fn_usuario_id('almoxarifado@techrental.com');
SET @g_dev = fn_usuario_id('gestor.software@techrental.com');
SET @g_pd  = fn_usuario_id('gestor.pd@techrental.com');
SET @g_ms  = fn_usuario_id('gestor.suporte@techrental.com');
SET @dir   = fn_usuario_id('diretoria@techrental.com');
SET @hash  = '$2y$10$NrTtS2ZxdG/DUOEHvty8ae5NH431Jldc190I6/wBSeWNVEZ8cg9SK';

-- ===================== SETORES =====================
CALL sp_setor_criar('rh', 'Recursos Humanos', 'RH');
SET @setor_rh = fn_setor_id('rh');
CALL t_afirmar('Setor: criar', @setor_rh IS NOT NULL);
CALL t_erro('Setor: sigla duplicada', "CALL sp_setor_criar('rh','Outro nome','Outro')", 'já existe');
CALL sp_setor_listar(1);
CALL sp_setor_atualizar(@setor_rh, 'rh', 'Recursos Humanos e Pessoas', 'Pessoas', 1);
CALL t_afirmar('Setor: atualizar', (SELECT nome_curto FROM setores WHERE id = @setor_rh) = 'Pessoas');
CALL t_erro('Setor: excluir com equipamentos é bloqueado', CONCAT('CALL sp_setor_excluir(', fn_setor_id('dev'), ')'), 'bloqueada');
CALL sp_setor_excluir(@setor_rh);
CALL t_afirmar('Setor: excluir', NOT EXISTS (SELECT 1 FROM setores WHERE sigla = 'rh'));

-- ===================== CATEGORIAS =====================
CALL sp_categoria_criar('Áudio e Vídeo');
SET @cat_av = (SELECT id FROM categorias WHERE nome = 'Áudio e Vídeo');
CALL t_afirmar('Categoria: criar', @cat_av IS NOT NULL);
CALL t_erro('Categoria: nome duplicado', "CALL sp_categoria_criar('Notebooks')", 'já existe');
CALL sp_categoria_atualizar(@cat_av, 'Áudio, Vídeo e Imagem');
CALL t_afirmar('Categoria: atualizar', EXISTS (SELECT 1 FROM categorias WHERE id = @cat_av AND nome = 'Áudio, Vídeo e Imagem'));
CALL t_erro('Categoria: excluir com itens é bloqueado', "CALL sp_categoria_excluir(1)", 'bloqueada');
CALL sp_categoria_listar();

-- ===================== USUÁRIOS =====================
CALL t_erro('Usuário: gestor sem setor é recusado', CONCAT("CALL sp_usuario_criar('Fulano','fulano@techrental.com','", @hash, "','GESTOR',NULL)"), 'exige um setor');
CALL t_erro('Usuário: diretoria com setor é recusada', CONCAT("CALL sp_usuario_criar('Fulano','fulano@techrental.com','", @hash, "','DIRETORIA',1)"), 'exige um setor');
CALL sp_usuario_criar('Novo Gestor', 'Novo.Gestor@TechRental.com', @hash, 'GESTOR', fn_setor_id('pd'));
SET @novo = fn_usuario_id('novo.gestor@techrental.com');
CALL t_afirmar('Usuário: criar (e-mail vai para minúsculo)', @novo IS NOT NULL);
CALL t_erro('Usuário: e-mail duplicado', CONCAT("CALL sp_usuario_criar('Outro','novo.gestor@techrental.com','", @hash, "','ALMOXARIFADO',NULL)"), 'já existe');
CALL sp_usuario_atualizar(@novo, 'Novo Gestor Campo', 'novo.gestor@techrental.com', 'GESTOR', fn_setor_id('cp'), 1);
CALL t_afirmar('Usuário: atualizar', (SELECT setor_id FROM usuarios WHERE id = @novo) = fn_setor_id('cp'));
CALL sp_usuario_alterar_senha(@novo, '$2y$10$YpQ/mqX575MTB0Ipjres9Oe9EjI1ppUJ.B.SBdSdEqKm.hG6zun4C');
CALL sp_usuario_login('NOVO.gestor@techrental.com');
CALL sp_usuario_atualizar(@novo, 'Novo Gestor Campo', 'novo.gestor@techrental.com', 'GESTOR', fn_setor_id('cp'), 0);
CALL t_afirmar('Usuário: inativo não loga', (SELECT COUNT(*) FROM usuarios WHERE email='novo.gestor@techrental.com' AND ativo=1) = 0);
CALL sp_usuario_listar('GESTOR', NULL, 1);
CALL sp_usuario_excluir(@novo);
CALL t_afirmar('Usuário: excluir sem histórico', fn_usuario_id('novo.gestor@techrental.com') IS NULL);
CALL t_erro('Usuário: excluir com histórico é bloqueado', CONCAT('CALL sp_usuario_excluir(', @g_dev, ')'), 'Desative');

-- ===================== EQUIPAMENTOS =====================
CALL sp_equipamento_criar('note-dev-007', 'Notebook de Testes', 1, fn_setor_id('dev'), 'INTEGRO', 'Testes gerais');
SET @eq_novo = fn_equipamento_id('NOTE-DEV-007');
CALL t_afirmar('Equipamento: criar (código vai para maiúsculo)', @eq_novo IS NOT NULL);
CALL t_erro('Equipamento: código duplicado', "CALL sp_equipamento_criar('NOTE-DEV-007','Outro',1,1,'INTEGRO',NULL)", 'já está cadastrado');
CALL sp_equipamento_atualizar(@eq_novo, 'NOTE-DEV-007', 'Notebook de Testes 2', 1, fn_setor_id('dev'), 'COM_MARCAS_DE_USO', 'Testes gerais');
CALL t_afirmar('Equipamento: atualizar', (SELECT nome FROM equipamentos WHERE id = @eq_novo) = 'Notebook de Testes 2');
CALL t_afirmar('Equipamento: listar com filtro de setor', (SELECT COUNT(*) FROM vw_equipamentos WHERE setor_sigla = 'dev') = 7);
CALL sp_equipamento_listar(NULL, NULL, 'ATRASADO', NULL);
CALL sp_equipamento_listar(NULL, fn_setor_id('pd'), NULL, 'solda');
CALL sp_equipamento_obter_por_codigo('NOTE-DEV-001');
CALL sp_equipamento_excluir(@eq_novo);
CALL t_afirmar('Equipamento: excluir sem histórico', fn_equipamento_id('NOTE-DEV-007') IS NULL);
CALL t_erro('Equipamento: excluir com histórico é bloqueado', CONCAT('CALL sp_equipamento_excluir(', fn_equipamento_id('NOTE-DEV-002'), ')'), 'bloqueada');
CALL t_erro('Equipamento: descartado não edita', CONCAT("CALL sp_equipamento_atualizar(", fn_equipamento_id('FONT-PD-005'), ",'FONT-PD-005','X',4,", fn_setor_id('pd'), ",'INTEGRO',NULL)"), 'descartado');

-- ===================== EMPRÉSTIMO: solicitar / editar / cancelar / recusar / aprovar =====================
SET @prazo = DATE_ADD(CURDATE(), INTERVAL 7 DAY);
CALL t_afirmar('Atraso não bloqueia o setor (gestor Software tem itens atrasados)', (SELECT COUNT(*) FROM vw_emprestimos_ativos WHERE setor_sigla='dev' AND atrasado=1) > 0);
CALL t_erro('Solicitar: sem aceite do termo', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @g_dev, ",'[\"NOTE-DEV-002\"]','", @prazo, "',0)"), 'termo');
CALL t_erro('Solicitar: item emprestado', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @g_dev, ",'[\"NOTE-DEV-001\"]','", @prazo, "',1)"), 'indisponível');
CALL t_erro('Solicitar: item de outro setor', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @g_dev, ",'[\"SENS-PD-002\"]','", @prazo, "',1)"), 'próprio setor');
CALL t_erro('Solicitar: prazo no passado', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @g_dev, ",'[\"NOTE-DEV-002\"]','2020-01-01',1)"), 'futura');
CALL t_erro('Solicitar: código inexistente', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @g_dev, ",'[\"XXX-000\"]','", @prazo, "',1)"), 'inexistente');
CALL t_erro('Solicitar: almoxarifado não pede', CONCAT("CALL sp_emprestimo_solicitar('OS-T-1',", @almox, ",'[\"NOTE-DEV-002\"]','", @prazo, "',1)"), 'gestores');
CALL sp_emprestimo_solicitar('OS-T-1', @g_dev, '["NOTE-DEV-002","SRV-DEV-005","KIT-DEV-006"]', @prazo, 1);
SET @e1 = (SELECT id FROM emprestimos WHERE codigo_os='OS-T-1' AND equipamento_id=fn_equipamento_id('NOTE-DEV-002'));
SET @e2 = (SELECT id FROM emprestimos WHERE codigo_os='OS-T-1' AND equipamento_id=fn_equipamento_id('SRV-DEV-005'));
SET @e3 = (SELECT id FROM emprestimos WHERE codigo_os='OS-T-1' AND equipamento_id=fn_equipamento_id('KIT-DEV-006'));
CALL t_afirmar('Solicitar: 3 itens na mesma OS, todos PENDENTE', (SELECT COUNT(*) FROM emprestimos WHERE codigo_os='OS-T-1' AND status='PENDENTE') = 3);
CALL t_afirmar('Solicitar: item só vira Emprestado após aprovação', (SELECT status FROM equipamentos WHERE id = fn_equipamento_id('NOTE-DEV-002')) = 'DISPONIVEL');
CALL sp_emprestimo_atualizar(@e1, 'OS-T-1B', DATE_ADD(CURDATE(), INTERVAL 8 DAY));
CALL t_afirmar('Empréstimo: atualizar pendente', (SELECT codigo_os FROM emprestimos WHERE id=@e1) = 'OS-T-1B');
CALL sp_emprestimo_cancelar(@e3, @g_dev);
CALL t_afirmar('Empréstimo: cancelar pendente', (SELECT status FROM emprestimos WHERE id=@e3) = 'CANCELADO');
CALL sp_emprestimo_excluir(@e3);
CALL t_afirmar('Empréstimo: excluir cancelado', NOT EXISTS (SELECT 1 FROM emprestimos WHERE id=@e3));
CALL t_erro('Recusar: motivo obrigatório', CONCAT('CALL sp_emprestimo_recusar(', @e2, ',', @almox, ",'')"), 'motivo');
CALL t_erro('Aprovar: gestor não pode', CONCAT('CALL sp_emprestimo_aprovar(', @e1, ',', @g_dev, ')'), 'Almoxarifado');
CALL sp_emprestimo_recusar(@e2, @almox, 'Item reservado para outro projeto');
CALL t_afirmar('Empréstimo: recusar', (SELECT status FROM emprestimos WHERE id=@e2) = 'RECUSADO');
CALL sp_emprestimo_aprovar(@e1, @almox);
CALL t_afirmar('Aprovar: empréstimo ATIVO e item EMPRESTADO',
  (SELECT status FROM emprestimos WHERE id=@e1) = 'ATIVO' AND (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('NOTE-DEV-002')) = 'EMPRESTADO');
CALL t_erro('Aprovar duas vezes', CONCAT('CALL sp_emprestimo_aprovar(', @e1, ',', @almox, ')'), 'não está pendente');
CALL t_erro('Excluir empréstimo ativo é bloqueado', CONCAT('CALL sp_emprestimo_excluir(', @e1, ')'), 'bloqueada');
CALL sp_emprestimo_listar('ATIVO', fn_setor_id('dev'), NULL);
CALL sp_emprestimo_obter(@e1);

-- Aprova as pendentes do seed para testar a trava de 1 empréstimo ativo por item
CALL t_erro('Ativo único: inserir 2º empréstimo ativo do mesmo item',
  CONCAT("INSERT INTO emprestimos (codigo_os,equipamento_id,setor_id,solicitante_id,status,aceite_termo,solicitado_em,retirado_em,prazo_original,prazo_devolucao) VALUES ('X',", fn_equipamento_id('NOTE-DEV-002'), ",1,", @g_dev, ",'ATIVO',1,NOW() - INTERVAL 1 DAY,NOW(),NOW() + INTERVAL 1 DAY,NOW() + INTERVAL 1 DAY)"), 'Duplicate');

-- ===================== EXTENSÃO DE PRAZO =====================
CALL t_erro('Extensão: justificativa obrigatória', CONCAT('CALL sp_extensao_solicitar(', @e1, ',', @g_dev, ",'", DATE_ADD(CURDATE(), INTERVAL 20 DAY), "','')"), 'justificativa');
CALL t_erro('Extensão: gestor de outro setor', CONCAT('CALL sp_extensao_solicitar(', @e1, ',', @g_pd, ",'", DATE_ADD(CURDATE(), INTERVAL 20 DAY), "','Preciso')"), 'gestor do setor');
CALL t_erro('Extensão: data anterior ao prazo', CONCAT('CALL sp_extensao_solicitar(', @e1, ',', @g_dev, ",'", CURDATE(), "','Preciso')"), 'posterior');
CALL sp_extensao_solicitar(@e1, @g_dev, DATE_ADD(CURDATE(), INTERVAL 20 DAY), 'Cliente pediu mais tempo de homologação.');
SET @x1 = (SELECT id FROM extensoes_prazo WHERE emprestimo_id=@e1);
CALL t_afirmar('Extensão: criar (PENDENTE)', (SELECT status FROM extensoes_prazo WHERE id=@x1) = 'PENDENTE');
CALL t_erro('Extensão: só 1 por empréstimo', CONCAT('CALL sp_extensao_solicitar(', @e1, ',', @g_dev, ",'", DATE_ADD(CURDATE(), INTERVAL 25 DAY), "','De novo')"), 'Só é permitida 1');
CALL sp_extensao_atualizar(@x1, DATE_ADD(CURDATE(), INTERVAL 21 DAY), 'Cliente pediu mais tempo de homologação (ajustado).');
CALL t_afirmar('Extensão: atualizar pendente', (SELECT DATE(novo_prazo) FROM extensoes_prazo WHERE id=@x1) = DATE_ADD(CURDATE(), INTERVAL 21 DAY));
CALL t_erro('Extensão: gestor não decide', CONCAT('CALL sp_extensao_decidir(', @x1, ',', @g_dev, ',1)'), 'Diretoria');
CALL sp_extensao_decidir(@x1, @dir, 1);
CALL t_afirmar('Extensão: aprovar muda o prazo do empréstimo',
  (SELECT DATE(prazo_devolucao) FROM emprestimos WHERE id=@e1) = DATE_ADD(CURDATE(), INTERVAL 21 DAY));
CALL t_afirmar('Extensão: view mostra UTILIZADA', (SELECT extensao_status FROM vw_emprestimos_ativos WHERE emprestimo_id=@e1) = 'UTILIZADA');
CALL t_erro('Extensão: decidir 2 vezes', CONCAT('CALL sp_extensao_decidir(', @x1, ',', @dir, ',0)'), 'já foi decidido');
CALL t_erro('Extensão: excluir decidida é bloqueado', CONCAT('CALL sp_extensao_excluir(', @x1, ')'), 'bloqueada');
-- recusar e excluir pendente (usa uma extensão pendente do seed)
SET @x_seed = (SELECT x.id FROM extensoes_prazo x JOIN emprestimos e ON e.id=x.emprestimo_id WHERE e.codigo_os='OS-2026-0402');
CALL sp_extensao_decidir(@x_seed, @dir, 0);
CALL t_afirmar('Extensão: recusar mantém o prazo', (SELECT DATE(prazo_devolucao) FROM emprestimos WHERE codigo_os='OS-2026-0402') = '2026-11-10');
CALL sp_extensao_listar('PENDENTE', NULL);
SET @x_seed2 = (SELECT x.id FROM extensoes_prazo x JOIN emprestimos e ON e.id=x.emprestimo_id WHERE e.codigo_os='OS-2026-0377');
CALL sp_extensao_excluir(@x_seed2);
CALL t_afirmar('Extensão: excluir pendente', NOT EXISTS (SELECT 1 FROM extensoes_prazo WHERE id=@x_seed2));

-- ===================== DEVOLUÇÃO =====================
CALL t_erro('Devolução: defeito obrigatório', CONCAT('CALL sp_emprestimo_registrar_devolucao(', @e1, ',', @almox, ",'MANUTENCAO','','',NULL)"), 'defeito');
CALL t_erro('Devolução: motivo do descarte obrigatório', CONCAT('CALL sp_emprestimo_registrar_devolucao(', @e1, ',', @almox, ",'DESCARTE',NULL,'',NULL)"), 'descarte');
CALL t_erro('Devolução: só almoxarifado', CONCAT('CALL sp_emprestimo_registrar_devolucao(', @e1, ',', @g_dev, ",'DISPONIVEL',NULL,'',NULL)"), 'Almoxarifado');
-- 1) íntegro: item volta a Disponível
CALL sp_emprestimo_registrar_devolucao(@e1, @almox, 'DISPONIVEL', NULL, 'Conferido, sem avarias.', '[1,2,3,4,5]');
CALL t_afirmar('Devolução íntegra: item Disponível e empréstimo DEVOLVIDO',
  (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('NOTE-DEV-002')) = 'DISPONIVEL' AND (SELECT status FROM emprestimos WHERE id=@e1) = 'DEVOLVIDO');
CALL t_afirmar('Devolução: checklist gravado (5 itens)', (SELECT COUNT(*) FROM devolucao_checklist dc JOIN devolucoes d ON d.id=dc.devolucao_id WHERE d.emprestimo_id=@e1 AND dc.conferido=1) = 5);
CALL t_erro('Devolução: não devolve 2 vezes', CONCAT('CALL sp_emprestimo_registrar_devolucao(', @e1, ',', @almox, ",'DISPONIVEL',NULL,'',NULL)"), 'não está ativo');

-- 2) manutenção: devolve KIT-PD-001 com defeito -> oficina -> validação
SET @e_kit = (SELECT id FROM emprestimos WHERE codigo_os='OS-2026-0420');
CALL sp_emprestimo_registrar_devolucao(@e_kit, @almox, 'MANUTENCAO', 'Sensor com pino quebrado', 'Faltou tampa protetora', '[1,2,3]');
CALL t_afirmar('Devolução com defeito: item em Manutenção e registro EM_REPARO',
  (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('KIT-PD-001')) = 'MANUTENCAO'
  AND EXISTS (SELECT 1 FROM manutencoes WHERE equipamento_id=fn_equipamento_id('KIT-PD-001') AND etapa='EM_REPARO'));
SET @m1 = (SELECT id FROM manutencoes WHERE equipamento_id=fn_equipamento_id('KIT-PD-001') AND etapa='EM_REPARO');
CALL t_erro('Manutenção: validar antes da oficina concluir', CONCAT('CALL sp_manutencao_validar(', @m1, ',', @almox, ')'), 'ainda não foi concluído');
CALL t_erro('Manutenção: só o gestor do Suporte conclui', CONCAT('CALL sp_manutencao_concluir(', @m1, ',', @g_dev, ",'ok')"), 'Suporte');
CALL sp_manutencao_atualizar(@m1, 'Pino do sensor quebrado');
CALL sp_manutencao_concluir(@m1, @g_ms, 'Pino substituído e testado.');
CALL t_afirmar('Manutenção: concluir', (SELECT etapa FROM manutencoes WHERE id=@m1) = 'REPARO_CONCLUIDO');
CALL sp_manutencao_listar(NULL);
CALL sp_manutencao_validar(@m1, @almox);
CALL t_afirmar('Manutenção: validar devolve o item a Disponível',
  (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('KIT-PD-001')) = 'DISPONIVEL' AND (SELECT etapa FROM manutencoes WHERE id=@m1) = 'VALIDADA');
CALL t_erro('Manutenção: excluir validada é bloqueado', CONCAT('CALL sp_manutencao_excluir(', @m1, ')'), 'bloqueada');
-- envio direto + exclusão de registro aberto por engano
CALL sp_manutencao_abrir(fn_equipamento_id('SOLD-PD-003'), 'Ponta da solda oxidada', @almox);
SET @m2 = (SELECT id FROM manutencoes WHERE equipamento_id=fn_equipamento_id('SOLD-PD-003') AND etapa='EM_REPARO');
CALL t_afirmar('Manutenção: abrir direto', (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('SOLD-PD-003')) = 'MANUTENCAO');
CALL t_erro('Manutenção: 2ª abertura do mesmo item', CONCAT('CALL sp_manutencao_abrir(', fn_equipamento_id('SOLD-PD-003'), ",'Outra',", @almox, ')'), 'disponíveis');
CALL sp_manutencao_excluir(@m2);
CALL t_afirmar('Manutenção: excluir em reparo devolve o item a Disponível',
  (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('SOLD-PD-003')) = 'DISPONIVEL' AND NOT EXISTS (SELECT 1 FROM manutencoes WHERE id=@m2));

-- 3) descarte: gera alerta de compra -> Diretoria autoriza
SET @e_alic = (SELECT id FROM emprestimos WHERE codigo_os='OS-2026-0433');
CALL sp_emprestimo_registrar_devolucao(@e_alic, @almox, 'DESCARTE', 'Caiu de altura, perda total', NULL, '[1,2]');
CALL t_afirmar('Descarte: item Descartado e alerta de compra PENDENTE',
  (SELECT status FROM equipamentos WHERE id=fn_equipamento_id('ALIC-MS-002')) = 'DESCARTADO'
  AND EXISTS (SELECT 1 FROM alertas_compra WHERE equipamento_id=fn_equipamento_id('ALIC-MS-002') AND status='PENDENTE'));
SET @c1 = (SELECT id FROM alertas_compra WHERE equipamento_id=fn_equipamento_id('ALIC-MS-002'));
CALL sp_compra_atualizar(@c1, 'Caiu de altura: perda total (revisado)');
CALL t_erro('Compra: almoxarifado não autoriza', CONCAT('CALL sp_compra_autorizar(', @c1, ',', @almox, ')'), 'Diretoria');
CALL sp_compra_autorizar(@c1, @dir);
CALL t_afirmar('Compra: autorizar', (SELECT status FROM alertas_compra WHERE id=@c1) = 'AUTORIZADA');
CALL t_erro('Compra: excluir autorizada é bloqueado', CONCAT('CALL sp_compra_excluir(', @c1, ')'), 'bloqueada');
CALL sp_compra_listar('PENDENTE');
SET @c_seed = (SELECT id FROM alertas_compra WHERE equipamento_id=fn_equipamento_id('FONT-PD-005'));
CALL sp_compra_excluir(@c_seed);
CALL t_afirmar('Compra: excluir pendente', NOT EXISTS (SELECT 1 FROM alertas_compra WHERE id=@c_seed));
CALL sp_compra_registrar(fn_equipamento_id('FONT-PD-005'), 'Reposição da fonte assimétrica');
CALL t_afirmar('Compra: registrar para item descartado', EXISTS (SELECT 1 FROM alertas_compra WHERE equipamento_id=fn_equipamento_id('FONT-PD-005')));
CALL t_erro('Compra: item não descartado não gera alerta', CONCAT('CALL sp_compra_registrar(', fn_equipamento_id('NOTE-DEV-002'), ",'x')"), 'descartados');

-- ===================== HISTÓRICO / VIEWS =====================
CALL sp_historico_listar(fn_setor_id('dev'), NULL);
CALL t_afirmar('Histórico: devolução do NOTE-DEV-002 aparece como INTEGRO',
  EXISTS (SELECT 1 FROM vw_historico WHERE codigo_os='OS-T-1B' AND destino_vistoria='INTEGRO'));
CALL t_afirmar('Painel: indicadores gerais respondem', (SELECT ativos_registrados FROM vw_indicadores_gerais) = 24);

-- ===================== RESULTADO =====================
SELECT n, teste, resultado FROM t_resultados ORDER BY n;
SELECT SUM(resultado = 'OK') AS ok, SUM(resultado <> 'OK') AS falhas, COUNT(*) AS total FROM t_resultados;

DROP PROCEDURE t_afirmar;
DROP PROCEDURE t_erro;
