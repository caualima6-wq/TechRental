# TechRental · site ligado ao banco MySQL

As telas agora leem e gravam no banco. Os dados passam de uma página para outra e se atualizam sozinhos
(a cada 3 segundos, o indicador "ao vivo" fica no topo): se o Almoxarifado aprova uma retirada, o gestor vê na hora, sem recarregar.

## Instalar (PHP 8+ com PDO MySQL, MySQL 8.0.16+)

```bash
mysql -u root -p < banco/techrental_completo.sql     # cria o banco "techrental" com os dados de exemplo
mysql -u root -p < banco/criar_usuario_app.sql       # cria o usuário techrental_app (TROQUE a senha no arquivo)
# coloque a mesma senha em api/config.php (ou use as variáveis TR_DB_HOST, TR_DB_NAME, TR_DB_USER, TR_DB_PASS)
php -S 127.0.0.1:8000                                # teste local; em produção use Apache/Nginx + PHP-FPM
```
Abra `http://127.0.0.1:8000/login.php`. Senha de todos os usuários de exemplo: `12345678`
(almoxarifado@, gestor.software@, gestor.pd@, gestor.campo@, gestor.suporte@, diretoria@ + `techrental.com`).

> `techrental_completo.sql` começa com `DROP DATABASE`. É só para desenvolvimento: remova essa linha antes de usar com dados reais.
> Em produção, use HTTPS e bloqueie o acesso web às pastas `banco/` e `api/config.php` (já há um `.htaccess` para Apache).

## Como funciona

| Arquivo | Papel |
|---|---|
| `login.php` | (GET) mostra a tela de login; (POST) confere e-mail e senha no banco (`sp_usuario_login`) e abre a **sessão PHP** |
| `api.php` | `estado` (dados que o perfil pode ver) e as ações de CRUD/fluxo, todas via procedures do banco |
| `api/db.php`, `api/config.php` | conexão PDO, erros de regra de negócio em português, configuração |
| `js/app.js` | desenha as telas com os dados do banco e confere mudanças a cada 3 s |

Segurança: o id e o perfil de quem age vêm só da sessão; todo POST exige token CSRF; cada perfil só recebe os dados que pode ver
(o gestor só recebe o próprio setor); usuário desativado perde a sessão na hora; tudo que vem do banco é escapado no HTML.

## CRUD por tela

| Entidade | Onde | Criar | Ler | Atualizar | Excluir |
|---|---|---|---|---|---|
| Equipamentos | Cadastros › Equipamentos | ✔ | Catálogo / Detalhe | ✔ | ✔ (bloqueado se tem histórico) |
| Categorias | Cadastros › Categorias | ✔ | ✔ | ✔ | ✔ (bloqueado se tem itens) |
| Usuários | Cadastros › Usuários | ✔ | ✔ | ✔ (inclui senha e ativar/desativar) | ✔ (bloqueado se tem histórico) |
| Setores | Cadastros › Setores | ✔ | ✔ | ✔ | ✔ (bloqueado se tem itens/usuários) |
| Retiradas | Nova retirada / Meus empréstimos | ✔ | ✔ | ✔ (pendentes) | ✔ cancelar (pendentes) |
| Extensões | Extensões | ✔ | ✔ | ✔ (pendentes) | ✔ cancelar (pendentes) |
| Manutenção | Manutenção / Oficina | ✔ | ✔ | concluir / validar | ✔ (em reparo) |
| Devolução, compra | Registrar devolução / Aprovações | ✔ | ✔ | autorizar compra | histórico não se apaga |

As regras de negócio (1 extensão por empréstimo, só o Almoxarifado devolve, etc.) ficam no banco: veja `banco/README_banco.md`.
