<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TechRental</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/app.css">
</head>
<body class="pagina-interna" data-p="painel">
  <div id="app"></div>
  <script src="js/app.js"></script>
</body>
</html>
