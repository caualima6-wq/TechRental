<?php
// Login do TechRental: confere e-mail e senha no BANCO (sp_usuario_login) e abre a sessão PHP.
// A partir daqui o perfil e o id do usuário vivem só no servidor (o navegador não decide nada).
// GET: mostra a tela de login (antes era login.html). POST: autentica.
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TechRental</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/painel.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/app.css">
</head>
<body class="pagina-login" data-p="login">
  <div id="app"></div>
  <script src="js/app.js"></script>
</body>
</html>
<?php
    exit;
}

require __DIR__ . '/api/db.php';

$email = strtolower(trim((string)($_POST['email'] ?? '')));
$senha = (string)($_POST['senha'] ?? '');

try {
    $u = chamar('sp_usuario_login', [$email])[0] ?? null;
    // password_verify roda mesmo se o e-mail não existir: o tempo de resposta não revela nada.
    $hash = $u['senha_hash'] ?? '$2y$10$usesomesillystringforsalt.abcdefghijklmnopqrstuv';
    $ok = password_verify($senha, $hash) && $u !== null;
    if (!$ok) {
        usleep(400000); // dificulta tentativa em massa
        responder(401, ['ok' => false]);
    }
    session_regenerate_id(true);
    $_SESSION['u'] = ['id' => (int)$u['id'], 'p' => $u['p'], 's' => (string)$u['s']];
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
    chamar('sp_usuario_registrar_login', [$u['id']]);
    responder(200, ['ok' => true, 'p' => $u['p'], 's' => (string)$u['s']]);
} catch (Throwable $e) {
    tratar_erro($e);
}
