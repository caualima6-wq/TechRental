<?php
// API do TechRental. Tudo passa pelas procedures/views do banco (banco/techrental_completo.sql).
//   GET  api.php?a=estado[&h=<hash>]  -> dados que o perfil logado pode ver (se o hash não mudou: {"mudou":false})
//   POST api.php?a=<acao>             -> corpo JSON; exige o cabeçalho X-CSRF devolvido por "estado"
//   POST api.php?a=sair               -> encerra a sessão
// O id e o perfil de quem age vêm SEMPRE da sessão PHP, nunca do navegador.
require __DIR__ . '/api/db.php';

$u = usuario_logado();
if (!$u) responder(401, ['ok' => false, 'erro' => 'Sessão expirada. Entre novamente.', 'login' => true]);
$acao = (string)($_GET['a'] ?? '');
$metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    // O usuário ainda existe e está ativo? (desativar um usuário derruba a sessão dele na hora)
    $eu = chamar('sp_usuario_obter', [$u['id']])[0] ?? null;
    if (!$eu || !(int)$eu['ativo']) {
        $_SESSION = [];
        responder(401, ['ok' => false, 'erro' => 'Usuário inativo.', 'login' => true]);
    }
    $csrf = (string)($_SESSION['csrf'] ?? '');
    if ($acao !== 'sair') session_write_close();       // não prende a sessão enquanto a consulta roda (várias abas/polling)
    $uid = $u['id'];
    $perfil = $u['p'];                                 // a | g | d
    $meuSetorId = $eu['setor_id'] !== null ? (int)$eu['setor_id'] : null;
    $oficina = $perfil === 'g' && $u['s'] === 'ms';    // gestor de Manutenção e Suporte

    if ($acao === 'sair' && $metodo === 'POST') {
        $_SESSION = [];
        session_destroy();
        responder(200, ['ok' => true]);
    }

    if ($acao === 'estado' && $metodo === 'GET') {
        $e = montar_estado();
        $hash = md5(json_encode($e));
        if (($_GET['h'] ?? '') === $hash) responder(200, ['ok' => true, 'mudou' => false]);
        responder(200, ['ok' => true, 'mudou' => true, 'h' => $hash, 'csrf' => $csrf] + $e);
    }

    if ($metodo !== 'POST') responder(405, ['ok' => false, 'erro' => 'Método não permitido.']);
    if (!hash_equals($csrf, $_SERVER['HTTP_X_CSRF'] ?? '')) {
        responder(403, ['ok' => false, 'erro' => 'Requisição recusada (CSRF). Recarregue a página.']);
    }
    $d = json_decode(file_get_contents('php://input') ?: '{}', true);
    if (!is_array($d)) responder(400, ['ok' => false, 'erro' => 'Corpo inválido.']);

    $r = executar($acao, $d);
    responder(200, ['ok' => true] + $r);
} catch (Throwable $ex) {
    tratar_erro($ex);
}

/* ------------------------------------------------------------------ */

function exige(string ...$perfis): void {
    global $perfil;
    if (!in_array($perfil, $perfis, true)) responder(403, ['ok' => false, 'erro' => 'Seu perfil não tem permissão para esta ação.']);
}
function num($d, string $k): int { return (int)($d[$k] ?? 0); }
function txt($d, string $k): string { return trim((string)($d[$k] ?? '')); }
function ou_null(string $s): ?string { return $s === '' ? null : $s; }
function data_ok(string $s): ?string { return preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) ? $s : null; }

/** O empréstimo é do setor do gestor logado? */
function emprestimo_do_meu_setor(int $id): array {
    global $meuSetorId;
    $e = chamar('sp_emprestimo_obter', [$id])[0] ?? null;
    if (!$e) responder(422, ['ok' => false, 'erro' => 'Empréstimo não encontrado.']);
    if ((int)$e['setor_id'] !== $meuSetorId) responder(403, ['ok' => false, 'erro' => 'Este empréstimo é de outro setor.']);
    return $e;
}

function montar_estado(): array {
    global $perfil, $meuSetorId, $oficina, $eu, $u;
    $g = $perfil === 'g';
    $setorCurto = $g ? (chamar('sp_setor_obter', [$meuSetorId])[0]['nome_curto'] ?? '') : '';

    $eq   = consultar('SELECT * FROM vw_equipamentos' . ($g ? ' WHERE setor_id = ?' : '') . ' ORDER BY id', $g ? [$meuSetorId] : [])[0];
    $emp  = consultar('SELECT a.*, e.retirado_em FROM vw_emprestimos_ativos a JOIN emprestimos e ON e.id = a.emprestimo_id'
                      . ($g ? ' WHERE a.setor_id = ?' : '') . ' ORDER BY a.emprestimo_id', $g ? [$meuSetorId] : [])[0];
    $his  = consultar('SELECT * FROM vw_historico' . ($g ? ' WHERE setor_id = ?' : '') . ' ORDER BY retirado_em DESC, emprestimo_id DESC LIMIT 500', $g ? [$meuSetorId] : [])[0];
    $ext  = chamar('sp_extensao_listar', [null, $g ? $meuSetorId : null]);
    $sol  = [];
    if ($perfil === 'a') $sol = consultar('SELECT * FROM vw_solicitacoes_pendentes')[0];
    if ($g) $sol = chamar('sp_emprestimo_listar', ['PENDENTE', $meuSetorId, null]);
    $compra = $g ? [] : chamar('sp_compra_listar', [null]);
    $man  = ($perfil === 'a' || $oficina) ? chamar('sp_manutencao_listar', [null]) : [];
    $users = $perfil === 'a' ? chamar('sp_usuario_listar', [null, null, 0]) : [];

    return [
        'eu'       => ['id' => (int)$eu['id'], 'nome' => $eu['nome'], 'p' => $perfil, 's' => $u['s'], 'setor_id' => $meuSetorId],
        'setores'  => chamar('sp_setor_listar', [0]),
        'cats'     => chamar('sp_categoria_listar'),
        'eq'       => $eq,
        'emp'      => $emp,
        'sol'      => $sol,
        'ext'      => $ext,
        'compra'   => $compra,
        'man'      => $man,
        'his'      => $his,
        'usuarios' => $users,
    ];
}

function executar(string $acao, array $d): array {
    global $uid, $perfil, $meuSetorId, $oficina;
    switch ($acao) {

    /* ---------- Empréstimos (retiradas) ---------- */
    case 'retirada_solicitar':
        exige('g');
        $cods = array_values(array_filter(array_map('strval', (array)($d['codigos'] ?? []))));
        chamar('sp_emprestimo_solicitar', [txt($d, 'codigo_os'), $uid, json_encode($cods), data_ok(txt($d, 'prazo')), !empty($d['aceite']) ? 1 : 0]);
        return ['msg' => 'Solicitação enviada ao Almoxarifado.'];
    case 'retirada_editar':
        exige('g');
        $e = emprestimo_do_meu_setor(num($d, 'id'));
        if ((int)$e['solicitante_id'] !== $uid) responder(403, ['ok' => false, 'erro' => 'Só quem fez o pedido pode editá-lo.']);
        chamar('sp_emprestimo_atualizar', [num($d, 'id'), txt($d, 'codigo_os'), data_ok(txt($d, 'prazo'))]);
        return ['msg' => 'Solicitação atualizada.'];
    case 'retirada_cancelar':
        exige('g');
        emprestimo_do_meu_setor(num($d, 'id'));
        chamar('sp_emprestimo_cancelar', [num($d, 'id'), $uid]);
        return ['msg' => 'Solicitação cancelada.'];
    case 'retirada_aprovar':
        exige('a');
        chamar('sp_emprestimo_aprovar', [num($d, 'id'), $uid]);
        return ['msg' => 'Retirada aprovada: o item agora está Emprestado.'];
    case 'retirada_recusar':
        exige('a');
        chamar('sp_emprestimo_recusar', [num($d, 'id'), $uid, ou_null(txt($d, 'motivo'))]);
        return ['msg' => 'Retirada recusada.'];

    /* ---------- Devolução ---------- */
    case 'devolucao':
        exige('a');
        $lista = array_values(array_map('intval', (array)($d['checklist'] ?? [])));
        $r = chamar('sp_emprestimo_registrar_devolucao', [num($d, 'id'), $uid, txt($d, 'destino'), ou_null(txt($d, 'detalhe')), ou_null(txt($d, 'observacao')), json_encode($lista)]);
        return ['msg' => 'Devolução registrada.', 'resultado' => $r[0] ?? null];

    /* ---------- Extensões de prazo ---------- */
    case 'extensao_solicitar':
        exige('g');
        emprestimo_do_meu_setor(num($d, 'emprestimo_id'));
        chamar('sp_extensao_solicitar', [num($d, 'emprestimo_id'), $uid, data_ok(txt($d, 'novo_prazo')), txt($d, 'justificativa')]);
        return ['msg' => 'Pedido enviado à Diretoria. Status: pendente.'];
    case 'extensao_editar':
    case 'extensao_cancelar':
        exige('g');
        $x = chamar('sp_extensao_obter', [num($d, 'id')])[0] ?? null;
        if (!$x) responder(422, ['ok' => false, 'erro' => 'Pedido de extensão não encontrado.']);
        emprestimo_do_meu_setor((int)$x['emprestimo_id']);
        if ($acao === 'extensao_editar') {
            chamar('sp_extensao_atualizar', [num($d, 'id'), data_ok(txt($d, 'novo_prazo')), txt($d, 'justificativa')]);
            return ['msg' => 'Pedido de extensão atualizado.'];
        }
        chamar('sp_extensao_excluir', [num($d, 'id')]);
        return ['msg' => 'Pedido de extensão cancelado.'];
    case 'extensao_decidir':
        exige('d');
        chamar('sp_extensao_decidir', [num($d, 'id'), $uid, !empty($d['aprovar']) ? 1 : 0]);
        return ['msg' => !empty($d['aprovar']) ? 'Extensão aprovada.' : 'Extensão recusada.'];

    /* ---------- Manutenção ---------- */
    case 'manutencao_abrir':
        exige('a');
        chamar('sp_manutencao_abrir', [num($d, 'equipamento_id'), txt($d, 'motivo'), $uid]);
        return ['msg' => 'Item enviado à manutenção.'];
    case 'manutencao_concluir':
        if (!$oficina) responder(403, ['ok' => false, 'erro' => 'Só o gestor de Manutenção e Suporte conclui reparos.']);
        chamar('sp_manutencao_concluir', [num($d, 'id'), $uid, ou_null(txt($d, 'observacao'))]);
        return ['msg' => 'Reparo concluído. Aguardando validação do Almoxarifado.'];
    case 'manutencao_validar':
        exige('a');
        chamar('sp_manutencao_validar', [num($d, 'id'), $uid]);
        return ['msg' => 'Recebimento validado: item Disponível.'];
    case 'manutencao_excluir':
        exige('a');
        chamar('sp_manutencao_excluir', [num($d, 'id')]);
        return ['msg' => 'Manutenção removida; o item voltou a Disponível.'];

    /* ---------- Compra ---------- */
    case 'compra_autorizar':
        exige('d');
        chamar('sp_compra_autorizar', [num($d, 'id'), $uid]);
        return ['msg' => 'Compra autorizada.'];

    /* ---------- Cadastros: equipamentos ---------- */
    case 'equipamento_criar':
        exige('a');
        $r = chamar('sp_equipamento_criar', [codigo_ok(txt($d, 'codigo')), txt($d, 'nome'), num($d, 'categoria_id'), num($d, 'setor_id'), txt($d, 'condicao') ?: 'INTEGRO', ou_null(txt($d, 'uso'))]);
        return ['msg' => 'Equipamento cadastrado.', 'id' => $r[0]['id'] ?? null];
    case 'equipamento_atualizar':
        exige('a');
        chamar('sp_equipamento_atualizar', [num($d, 'id'), codigo_ok(txt($d, 'codigo')), txt($d, 'nome'), num($d, 'categoria_id'), num($d, 'setor_id'), txt($d, 'condicao') ?: 'INTEGRO', ou_null(txt($d, 'uso'))]);
        return ['msg' => 'Equipamento atualizado.'];
    case 'equipamento_excluir':
        exige('a');
        chamar('sp_equipamento_excluir', [num($d, 'id')]);
        return ['msg' => 'Equipamento excluído.'];

    /* ---------- Cadastros: categorias ---------- */
    case 'categoria_criar':
        exige('a');
        chamar('sp_categoria_criar', [txt($d, 'nome')]);
        return ['msg' => 'Categoria criada.'];
    case 'categoria_atualizar':
        exige('a');
        chamar('sp_categoria_atualizar', [num($d, 'id'), txt($d, 'nome')]);
        return ['msg' => 'Categoria atualizada.'];
    case 'categoria_excluir':
        exige('a');
        chamar('sp_categoria_excluir', [num($d, 'id')]);
        return ['msg' => 'Categoria excluída.'];

    /* ---------- Cadastros: setores ---------- */
    case 'setor_criar':
        exige('a');
        chamar('sp_setor_criar', [strtolower(txt($d, 'sigla')), txt($d, 'nome'), txt($d, 'nome_curto')]);
        return ['msg' => 'Setor criado.'];
    case 'setor_atualizar':
        exige('a');
        chamar('sp_setor_atualizar', [num($d, 'id'), strtolower(txt($d, 'sigla')), txt($d, 'nome'), txt($d, 'nome_curto'), isset($d['ativo']) && !$d['ativo'] ? 0 : 1]);
        return ['msg' => 'Setor atualizado.'];
    case 'setor_excluir':
        exige('a');
        chamar('sp_setor_excluir', [num($d, 'id')]);
        return ['msg' => 'Setor excluído.'];

    /* ---------- Cadastros: usuários ---------- */
    case 'usuario_criar':
        exige('a');
        $senha = (string)($d['senha'] ?? '');
        if (strlen($senha) < 8) responder(422, ['ok' => false, 'erro' => 'A senha deve ter ao menos 8 caracteres.']);
        $perf = perfil_banco(txt($d, 'perfil'));
        chamar('sp_usuario_criar', [txt($d, 'nome'), strtolower(txt($d, 'email')), password_hash($senha, PASSWORD_DEFAULT), $perf, $perf === 'GESTOR' ? num($d, 'setor_id') : null]);
        return ['msg' => 'Usuário criado.'];
    case 'usuario_atualizar':
        exige('a');
        $id = num($d, 'id');
        $ativo = isset($d['ativo']) && !$d['ativo'] ? 0 : 1;
        if ($id === $uid && !$ativo) responder(422, ['ok' => false, 'erro' => 'Você não pode desativar o próprio usuário.']);
        $perf = perfil_banco(txt($d, 'perfil'));
        if ($id === $uid && $perf !== 'ALMOXARIFADO') responder(422, ['ok' => false, 'erro' => 'Você não pode mudar o próprio perfil.']);
        chamar('sp_usuario_atualizar', [$id, txt($d, 'nome'), strtolower(txt($d, 'email')), $perf, $perf === 'GESTOR' ? num($d, 'setor_id') : null, $ativo]);
        $senha = (string)($d['senha'] ?? '');
        if ($senha !== '') {
            if (strlen($senha) < 8) responder(422, ['ok' => false, 'erro' => 'A senha deve ter ao menos 8 caracteres.']);
            chamar('sp_usuario_alterar_senha', [$id, password_hash($senha, PASSWORD_DEFAULT)]);
        }
        return ['msg' => 'Usuário atualizado.'];
    case 'usuario_excluir':
        exige('a');
        if (num($d, 'id') === $uid) responder(422, ['ok' => false, 'erro' => 'Você não pode excluir o próprio usuário.']);
        chamar('sp_usuario_excluir', [num($d, 'id')]);
        return ['msg' => 'Usuário excluído.'];
    }
    responder(404, ['ok' => false, 'erro' => 'Ação desconhecida.']);
}

/** Código de patrimônio: letras maiúsculas, números e hífen (ex.: NOTE-DEV-001). */
function codigo_ok(string $c): string {
    $c = strtoupper(trim($c));
    if (!preg_match('/^[A-Z0-9][A-Z0-9-]{1,19}$/', $c)) responder(422, ['ok' => false, 'erro' => 'O código de patrimônio deve ter letras, números e hífen (ex.: NOTE-DEV-007).']);
    return $c;
}

function perfil_banco(string $p): string {
    return ['a' => 'ALMOXARIFADO', 'g' => 'GESTOR', 'd' => 'DIRETORIA'][$p] ?? responder(422, ['ok' => false, 'erro' => 'Perfil inválido.']);
}
